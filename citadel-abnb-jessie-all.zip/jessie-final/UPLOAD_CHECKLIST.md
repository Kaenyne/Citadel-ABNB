# Upload checklist — Jessie's alt-data work (2026-09-06)

This folder is the complete, deduplicated set of everything Jessie has produced, laid out exactly as the repo expects.
It REPLACES the earlier partial uploads. Do this once, on a branch:

```bash
git checkout main && git pull
git checkout -b jessie/alt-data-consolidated

# 1. clean up the earlier uploads (they are all inside this folder already)
git rm -r "citadel-abnb-files 2"                    # Sept 4 drop, misplaced at root
git rm citadel-abnb-macro-topdown.zip citadel-abnb-austin-rnpl-hotels.zip   # zips committed at root; *.zip is gitignored for a reason

# 2. copy this folder's contents onto the repo root (folders merge; no teammate file is overwritten)
cp -R /path/to/jessie-final/. .

# 3. paste the README rows, then delete the two helper files
#    data/README_jessie_rows.md            -> rows into data/README.md
#    research/sources/README_jessie_rows.md -> rows into research/sources/README.md
git rm data/README_jessie_rows.md research/sources/README_jessie_rows.md UPLOAD_CHECKLIST.md

git add -A && git commit -m "Jessie: alt-data workstream (air traffic, macro, Austin STR, Airbnb-vs-hotel choice, crowding)"
git push -u origin jessie/alt-data-consolidated   # then open a PR
```

Not included on purpose (already in the repo or a teammate's branch — see data/README_jessie_rows.md, last section):
unearned-fees CSV (Theo's abnb_edgar_quarterly_kpis.csv has it), EU27 platform nights CSV (Krishang's eurostat_platform_nights_monthly.csv),
Inside Airbnb listing counts (Theo's manifest), requirements.txt (repo's already covers pandas/numpy/matplotlib/openpyxl; add `statsmodels scipy` to it),
and every raw input (listings.csv.gz, DBEDT xlsx, Eurostat JSON, FRED txt) — gitignored under data/raw, rebuilt by the named scripts.
