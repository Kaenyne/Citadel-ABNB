# Jessie — rows to append to data/README.md (all drops, deduplicated, 2026-09-06)

Paste these under the existing table in `data/README.md`, then delete this file.

| File | Source | Pulled by | Date | Notes |
|---|---|---|---|---|
| processed/tsa_checkpoint_monthly.csv | TSA daily checkpoint counts, summed to months (tsa.gov/travel/passenger-volumes) | Jessie (via Claude) | 2026-09-04 | 2022-01→2026-06; sums verified vs TSA annual totals |
| processed/bts_us_airline_passengers_monthly.csv | BTS monthly U.S. Airline Traffic Data releases | Jessie (via Claude) | 2026-09-04 | 2022 SA, 2023+ NSA — level break |
| processed/iata_rpk_yoy_monthly.csv | IATA Air Passenger Market Analysis (global RPK YoY) | Jessie (via Claude) | 2026-09-04 | 2023-01→2026-07 |
| processed/iata_rpk_yoy_by_region_monthly.csv | IATA regional RPK YoY (by airline registration) | Jessie (via Claude) | 2026-09-04 | 2024-01→2026-07; May/Nov-24 international-only |
| processed/ntto_us_inbound_monthly.csv | NTTO US international inbound arrivals YoY | Jessie (via Claude) | 2026-09-04 | basis varies by month (air-only vs total) |
| processed/airbnb_quarterly_kpis.csv | Airbnb shareholder letters (nights, GBV, revenue) | Jessie (via Claude) | 2026-09-04 | 2022Q1→2026Q2, as reported |
| processed/airbnb_regional_revenue_quarterly.csv | Airbnb 10-Q/10-K revenue by geographic region (SEC R-pages) | Jessie (via Claude) | 2026-09-04 | Q4s derived as FY minus 9M |
| processed/abnb_monthly_close.csv | Yahoo Finance monthly closes | Jessie (via Claude) | 2026-09-04 | 2021-12→2026-08 |
| processed/destination_air_vs_str_snapshot.csv | Airport authorities + AirDNA/AirROI/DBEDT | Jessie (via Claude) | 2026-09-04 | mixed metrics/periods — see columns |
| processed/top_airbnb_cities_listings_airports.csv | AirROI active listings + airport traffic releases | Jessie (via Claude) | 2026-09-04 | STR YoY only for NYC/LA/Sydney |
| processed/macro_us_monthly.csv | FRED monthly: Michigan sentiment, unemployment, CPI, real DPI, saving rate, fed funds, 10y yield, broad dollar index, WTI, real PCE, EUR/USD | Jessie (via Claude) | 2026-09-05 | 2021-01→2026-08 where available |
| processed/us_real_gdp_growth_quarterly.csv | FRED A191RL1Q225SBEA real GDP growth (SAAR) | Jessie (via Claude) | 2026-09-05 | 2021Q1→2026Q2 |
| processed/sp500_monthly_close.csv | Yahoo Finance ^GSPC month-end close | Jessie (via Claude) | 2026-09-05 | 2021-12→2026-08 |
| processed/airbnb_adr_takerate_quarterly.csv | ADR and quarterly take rate, from research/airbnb_earnings_call_study.md (Krishang) | Jessie (via Claude) | 2026-09-05 | 2021Q1→2026Q2 |
| processed/nyc_ose_enforcement_2024_2025.csv | NYC Office of Special Enforcement annual reports (LL18) | Jessie (Claude) | 2026-09-05 | Complaints, inspections, summonses, penalties 2024 vs 2025. |
| processed/vancouver_str_business_licences.csv | City of Vancouver open data, STR business licences | Jessie (Claude) | 2026-09-05 | Annual licence counts. |
| processed/austin_active_str_daily.csv | City of Austin Development Services, Socrata `mydx-h5dy` (Active Short Term Rental Counts) | Jessie (Claude) | 2026-09-05 | Daily total active STR licences, 2025-02-28 + 2025-03-13..2026-09-05 (527 dates). SoQL in `analysis/src/austin_str_daily.py`. Licences, not listings. Open government data. |
| processed/austin_str_by_type_monthly_raw.csv | same | Jessie (Claude) | 2026-09-05 | Sum of daily counts per month x licence type; divide by dates-in-month (script does it) for a monthly average. |
| processed/austin_str_by_type_monthly_avg.csv | derived | Jessie (Claude) | 2026-09-05 | Monthly average active licences by type. Rebuild: `python analysis/src/austin_str_daily.py`. |
| processed/austin_str_by_district_type_snapshots.csv | same Socrata dataset | Jessie (Claude) | 2026-09-05 | 2025-03-13 vs 2026-09-05, council district x licence type. |
| processed/hawaii_dbedt_2024_accommodation_by_market.csv | Hawaii DBEDT 2024 Annual Visitor Research Report (tables 15-35) | Jessie (Claude) | 2026-09-06 | Hotel/condo/timeshare/rental-home share, stay length, first-time %, purpose by source market. Public. |
| processed/hawaii_dbedt_2024_accommodation_by_island.csv | same, tables 57/59/62/63 | Jessie (Claude) | 2026-09-06 | Accommodation and purpose shares by island. |
| processed/hawaii_dbedt_2024_characteristics_by_accommodation.csv | same, tables 42-49 (companion Excel) | Jessie (Claude) | 2026-09-06 | Party size, independent vs package, stay length, purpose, age for hotel-only / condo-only / timeshare-only / rental-house-only visitors. The direct "who picks a rental" table. |
| processed/hawaii_dbedt_2024_crowding_by_island.csv | same, tables 8, 105-108 (STR), 110 (Visitor Plant Inventory) | Jessie (Claude) | 2026-09-06 | Daily visitor census, lodging units by type, hotel occupancy/ADR, derived visitors-per-unit. |
| processed/eurostat_platform_vs_hotel_by_country_2019_2024.csv | Eurostat tour_ce_oam, tour_occ_ninat (I551), tour_cap_nat (I551 bed places) | Jessie (Claude) | 2026-09-06 | Platform vs hotel nights, hotel bed occupancy, platform share, 2019 and 2024, 32 countries. Rebuild: `python analysis/src/eurostat_annual_platform_vs_hotel.py`. |
| processed/eurostat_platform_vs_hotel_monthly_2024.csv | Eurostat tour_ce_omr, tour_occ_nim (I551), tour_cap_nat | Jessie (Claude) | 2026-09-06 | Country x month 2024: platform nights, hotel nights, platform share, hotel bed occupancy. Platform-nights column overlaps Krishang's `eurostat_platform_nights_monthly.csv` (krish/eu-platform-backlog); the hotel side is new. Rebuild: `python analysis/src/crowding_hotel_vs_airbnb.py`. |
| processed/eurostat_crowding_tests_by_country_2024.csv | derived | Jessie (Claude) | 2026-09-06 | Per country: Spearman(platform share, hotel occupancy) over 12 months; share in 3 busiest vs 3 quietest hotel months. |
| processed/abnb_size_demand_pooled.csv, _pooled_us_only.csv, _by_market.csv, _5plus_by_market.csv, abnb_size_regression.csv | Inside Airbnb detailed listings, 13 markets (snapshots 2026-06-14..07-16), CC BY 4.0 | Jessie (Claude) | 2026-09-06 | Listing size (accommodates / bedrooms) vs share of bookings, guest-stays and estimated revenue; OLS with market FE. Raw files are gitignored: fetch with `analysis/src/download_us_listings.sh`, then `python analysis/src/listing_size_demand.py`. |

## Deliberately NOT included (already covered by a teammate)

- `abnb_unearned_fees_quarterly.csv` — same numbers as the `deferred_revenue` column in Theo's `data/processed/abnb_edgar_quarterly_kpis.csv`.
- `eurostat_eu27_platform_nights_monthly.csv` — Krishang's `eurostat_platform_nights_monthly.csv` (branch `krish/eu-platform-backlog`) has the same series for every country.
- `inside_airbnb_current_listing_counts.csv` — derivable from the `row_count` column of Theo's `data/manifests/inside_airbnb_download_log.csv`.
- Raw inputs (Inside Airbnb listings.csv.gz, DBEDT xlsx, Eurostat JSON, FRED txt) — gitignored under `data/raw/`; every processed file names the script that rebuilds it.
