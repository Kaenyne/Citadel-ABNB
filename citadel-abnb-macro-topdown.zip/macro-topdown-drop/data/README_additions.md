Rows to append to data/README.md:

| processed/macro_us_monthly.csv | FRED monthly: Michigan sentiment, unemployment, CPI, real DPI, saving rate, fed funds, 10y yield, broad dollar index, WTI, real PCE, EUR/USD | Jessie (via Claude) | 2026-09-05 | 2021-01→2026-08 where available |
| processed/us_real_gdp_growth_quarterly.csv | FRED A191RL1Q225SBEA real GDP growth (SAAR) | Jessie (via Claude) | 2026-09-05 | 2021Q1→2026Q2 |
| processed/sp500_monthly_close.csv | Yahoo Finance ^GSPC month-end close | Jessie (via Claude) | 2026-09-05 | 2021-12→2026-08 |
| processed/airbnb_adr_takerate_quarterly.csv | ADR and quarterly take rate, from research/airbnb_earnings_call_study.md (Krishang) | Jessie (via Claude) | 2026-09-05 | 2021Q1→2026Q2 |

Row to append to research/sources/README.md:

| S14 | FRED (Federal Reserve Bank of St. Louis) macro series | 2026-09-05 | https://fred.stlouisfed.org | macro top-down study |
