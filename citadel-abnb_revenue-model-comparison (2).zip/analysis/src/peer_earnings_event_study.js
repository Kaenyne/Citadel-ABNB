// Peer-earnings event study: does a BKNG / EXPE print move ABNB?
// Run in a browser tab opened on https://query1.finance.yahoo.com/ (same-origin fetch), e.g. DevTools console.
// Output: window.__sum (daily correlations, betas) and window.__ev (per-event table -> data/processed/peer_earnings_abnb_reaction.csv)
// Reporter dates are after-close reports; reaction day = next trading day. Market adjustment = return - beta_QQQ * QQQ return.
// "Clean" events (used for headline stats): reporter volume >= 1.5x trailing-20d median (date verified) AND ABNB volume < 2.5x (no own catalyst).
const T=['ABNB','BKNG','EXPE','QQQ'];const data={};
for(const s of T){const j=await fetch('/v8/finance/chart/'+s+'?range=6y&interval=1d').then(r=>r.json());const r=j.chart.result[0];const t=r.timestamp,ac=r.indicators.adjclose[0].adjclose,v=r.indicators.quote[0].volume;const m={};for(let i=0;i<t.length;i++){if(ac[i]==null)continue;m[new Date(t[i]*1000).toISOString().slice(0,10)]={p:ac[i],v:v[i]||0};}data[s]=m;}
const dates=Object.keys(data.ABNB).filter(d=>T.every(s=>data[s][d])).sort();
const ret={},vol={};for(const s of T){ret[s]=[];vol[s]=[];for(let i=0;i<dates.length;i++){vol[s].push(data[s][dates[i]].v);ret[s].push(i?Math.log(data[s][dates[i]].p/data[s][dates[i-1]].p):0);}}
function corr(a,b,mask){let n=0,sa=0,sb=0,saa=0,sbb=0,sab=0;for(let i=1;i<a.length;i++){if(mask&&!mask[i])continue;n++;sa+=a[i];sb+=b[i];saa+=a[i]*a[i];sbb+=b[i]*b[i];sab+=a[i]*b[i];}const ca=sab/n-(sa/n)*(sb/n),va=saa/n-(sa/n)**2,vb=sbb/n-(sb/n)**2;return [ca/Math.sqrt(va*vb),n,ca/vb];}
const [cAQ,nAll,betaAQ]=corr(ret.ABNB,ret.QQQ);const [,,betaBQ]=corr(ret.BKNG,ret.QQQ);const [,,betaEQ]=corr(ret.EXPE,ret.QQQ);
const resA=ret.ABNB.map((x,i)=>x-betaAQ*ret.QQQ[i]),resB=ret.BKNG.map((x,i)=>x-betaBQ*ret.QQQ[i]),resE=ret.EXPE.map((x,i)=>x-betaEQ*ret.QQQ[i]);
const BK='2021-02-24 2021-05-05 2021-08-04 2021-11-03 2022-02-23 2022-05-04 2022-08-03 2022-11-02 2023-02-23 2023-05-04 2023-08-03 2023-11-02 2024-02-22 2024-05-02 2024-08-01 2024-10-30 2025-02-20 2025-04-29 2025-07-29 2025-10-28 2026-02-18 2026-04-28 2026-08-03'.split(' ');
const EX='2021-02-12 2021-05-06 2021-08-05 2021-11-04 2022-02-10 2022-05-02 2022-08-08 2022-11-03 2023-02-09 2023-05-04 2023-08-03 2023-11-02 2024-02-08 2024-05-02 2024-08-08 2024-11-07 2025-02-06 2025-05-08 2025-08-07 2025-11-06 2026-02-12 2026-05-07 2026-08-05'.split(' ');
const med=a=>{const s=[...a].sort((x,y)=>x-y);return s[Math.floor(s.length/2)];};
const vs=(s,i)=>{const w=vol[s].slice(Math.max(0,i-21),i);return w.length?vol[s][i]/med(w):0;};
const ev=[];
for(const [rep,list] of [['BKNG',BK],['EXPE',EX]]){for(const d of list){const i=dates.findIndex(x=>x>d);if(i<3||i>=dates.length-3)continue;const rr=ret[rep][i],ra=ret.ABNB[i],rq=ret.QQQ[i];ev.push({rep,d,rd:dates[i],rr,abnRep:rr-(rep=='BKNG'?betaBQ:betaEQ)*rq,ra,rq,abn:ra-betaAQ*rq,c3:ret.ABNB[i]+ret.ABNB[i+1]+ret.ABNB[i+2]-betaAQ*(ret.QQQ[i]+ret.QQQ[i+1]+ret.QQQ[i+2]),vr:vs(rep,i),va:vs('ABNB',i)});}}
window.__ev=ev;
window.__sum={nAll,cAQ,betaAQ,cAB:corr(ret.ABNB,ret.BKNG)[0],cAE:corr(ret.ABNB,ret.EXPE)[0],cBE:corr(ret.BKNG,ret.EXPE)[0],rAB:corr(resA,resB)[0],rAE:corr(resA,resE)[0]};
console.table(ev);JSON.stringify(window.__sum);
