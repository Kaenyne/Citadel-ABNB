"""Headline stats for the peer-earnings event study (reads data/processed/peer_earnings_abnb_reaction.csv)."""
import pandas as pd, numpy as np
from scipy.stats import spearmanr
d = pd.read_csv('data/processed/peer_earnings_abnb_reaction.csv')
d['clean'] = (d.reporter_vol_ratio >= 1.5) & (d.abnb_vol_ratio < 2.5)
for rep in ['BKNG', 'EXPE']:
    g = d[(d.reporter == rep) & d.clean]
    x, y = g.reporter_abn_pct, g.abnb_abn_pct
    big = g[x.abs() >= 5]
    print(rep, dict(n=len(g), corr=round(np.corrcoef(x, y)[0, 1], 2), slope=round(np.polyfit(x, y, 1)[0], 2),
                    spearman=tuple(round(v, 2) for v in spearmanr(x, y)), same_sign=int((np.sign(x) == np.sign(y)).sum()),
                    mean_abs_abnb=round(y.abs().mean(), 2), mean_abs_peer=round(x.abs().mean(), 1),
                    n_big=len(big), corr_big=round(np.corrcoef(big.reporter_abn_pct, big.abnb_abn_pct)[0, 1], 2),
                    slope_big=round(np.polyfit(big.reporter_abn_pct, big.abnb_abn_pct, 1)[0], 2)))
    print('  excluded:', d[(d.reporter == rep) & ~d.clean].report_date.tolist())
