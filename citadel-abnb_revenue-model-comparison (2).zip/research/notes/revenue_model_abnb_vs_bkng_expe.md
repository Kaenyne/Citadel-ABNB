# Revenue model: Airbnb vs Booking Holdings vs Expedia Group

Author: Jessie (drafted with Claude), 2026-09-06
Data: `data/processed/revenue_model_comparison_fy2025.csv` (every figure carries its source URL)

## Bottom line

- Same *category*, not the same *model*. All three are asset-light two-sided marketplaces that book revenue **net** (as agent) as a % of gross bookings, recognized when the stay starts. That is where the similarity ends.
- Airbnb has **one** revenue stream (service fees on stays, plus small experiences/services fees), collects 100% of guest cash at booking, and charges a **visible guest-facing fee**. Booking and Expedia have **three to four** streams (merchant, agency, advertising, and for Expedia a large B2B wholesale segment), a mix of merchant and agency payment models, and fees that are mostly **invisible to the traveler** (embedded in the rate / paid by the supplier).
- FY2025 take rate (revenue / gross bookings): **BKNG 14.5%** > **ABNB 13.4%** > **EXPE 12.3%**. Booking's is rising (14.3% in FY2024) as it shifts to merchant; Airbnb's is slipping (Q4'25 13.6% vs 14.1% Q4'24); Expedia's is structurally lowest because B2B and air carry lower margins.

## 1. How each one actually earns a dollar

| | Airbnb | Booking Holdings | Expedia Group |
|---|---|---|---|
| Primary fee | Service fee on each stay. Split fee: host 3% (4% BR/MX) + guest 14.1–16.5% of subtotal. Host-only fee: 15.5% (16% BR/MX), mandatory for hotels, PMS-connected hosts and some countries. Experiences ~20%, Services ~15%. | Commission paid by the property on completed stays (rate set per country / property type; third-party guides put the typical rate near 15%). Under merchant model, also "transaction net revenues" (amount charged to traveler less amount owed to supplier), payment-facilitation revenue (card rebates, processing fees) and ancillary fees. | Merchant ("Expedia Collect"): Expedia is merchant of record, revenue = customer payment less negotiated net rate. Agency ("Hotel Collect"): commission from the hotel. Plus B2B (white-label / API supply to airlines, banks, offline agents) and advertising (trivago, EG media). |
| Who pays the fee | Both sides today; migrating toward host-only (fee invisible to guest) | Supplier (property); guest sees no separate fee | Supplier / embedded in price; guest sees no separate fee |
| Cash flow at booking | Airbnb collects the full stay amount at booking, holds it until check-in, pays host ~1 business day after check-in | Merchant bookings: collects at booking (70% of GB). Agency: never touches the cash | Merchant bookings: collects at booking (60% of GB). Agency: never touches the cash |
| Revenue recognition | Net; at check-in | Net; at check-in (accommodation) | Net; at stay (agency hotel), at booking (air) |
| Float / interest income | FY25 interest income $705mm on $6,959mm funds held for customers; = 5.8% of revenue, ~28% of net income | Earns on merchant float too, but not broken out the same way | Same, smaller |

Sources: Airbnb fee schedule ([Airbnb Help 1857](https://www.airbnb.com/help/article/1857)); host-only fee migration timeline ([Rental Scale-Up](https://www.rentalscaleup.com/airbnb-host-only-fee/)); Airbnb cash mechanics and 61% non-US revenue ([ABNB FY2025 10-K](https://www.sec.gov/Archives/edgar/data/1559720/000155972026000004/abnb-20251231.htm)); Airbnb interest income, S&M, unearned fees ([ABNB Q4'25 shareholder letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter.pdf)); Booking revenue definitions ([BKNG FY2025 10-K](https://www.sec.gov/Archives/edgar/data/1075531/000107553126000009/bkng-20251231.htm)); Booking commission mechanics ([Booking.com Partner Help](https://partner.booking.com/en-us/help/commission-invoices-tax/commission/understanding-our-commission); ~15% typical per [Lodgify](https://www.lodgify.com/guides/booking/fees/)); Expedia model definitions ([EXPE FY2025 10-K summary](https://www.stocktitan.net/sec-filings/EXPE/10-k-expedia-group-inc-files-annual-report-38a15f53cacb.html)).

## 2. FY2025 scale and mix

| FY2025 | ABNB | BKNG | EXPE |
|---|---|---|---|
| Revenue | $12.2B | $26.9B | $14.7B |
| Gross bookings | $91.3B (GBV) | $186.1B | $119.6B |
| Take rate | 13.4% | 14.5% (FY24: 14.3%) | 12.3% (Q4: 13.1%) |
| Merchant % of gross bookings | 100% | 69.9% (FY24: 62.9%) | 59.9% |
| Revenue mix | ~100% service fees | Merchant 66% / Agency 30% / Ads & other 4% | Merchant 70% / Agency 22% / Ads & other 8% |
| Segment mix | Single segment | Single reportable business (Booking.com dominant; also Priceline, Agoda, KAYAK, OpenTable) | B2C 64% / B2B 33% / trivago 3% |
| Lodging % of gross bookings | ~100% | not disclosed (flights GB $16.8B = 9%) | 73% |
| Units | 533.0mm nights & seats | 1,235mm room nights, 88mm car days, 68mm air tickets | 415.4mm room nights |
| Marketing % of revenue | 21% | 30% | n/a here |
| Net income / Adj. EBITDA | $2.5B / $4.3B (35% margin) | $5.4B / $9.9B | $1.3B / $3.5B |

Sources: [ABNB Q4'25 shareholder letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter.pdf); [BKNG Q4'25 earnings release](https://s201.q4cdn.com/865305287/files/doc_financials/2025/q4/Q4-25-BKNG-Earnings-Release.pdf); [BKNG FY25 marketing $8.2B, flights GB $16.8B — PhocusWire](https://www.phocuswire.com/booking-holdings-q4-full-year-2025-earnings); [EXPE Q4/FY25 release](https://ir.expediagroup.com/news-and-events/news/news-details/2026/Expedia-Group-Reports-Fourth-Quarter-and-Full-Year-2025-Results/default.aspx) and [BusinessWire tables](https://www.businesswire.com/news/home/20260212146454/en/Expedia-Group-Reports-Fourth-Quarter-and-Full-Year-2025-Results); Expedia 70/22/8 revenue-by-model from the [FY2025 10-K](https://www.stocktitan.net/sec-filings/EXPE/10-k-expedia-group-inc-files-annual-report-38a15f53cacb.html). Take rates and mix percentages are computed from the reported figures.

## 3. The five structural differences that matter for the pitch

1. **Fee visibility.** Airbnb is the only one whose core fee is a line item the guest sees (14.1–16.5%). That makes its take rate exposed to total-price-display rules, guest fee fatigue and hotel "book direct" comparisons in a way Booking/Expedia's supplier-paid commissions are not. The Oct–Dec 2025 migration of PMS and non-PMS hosts to a single 15.5% host-only fee is Airbnb moving toward the OTA convention — the fee disappears from the guest's checkout and the host is expected to reprice (Rental Scale-Up estimates hosts need ~+14.8% on rate to keep payout flat).
2. **Take-rate levers.** Booking's take rate is climbing because merchant mix went 63% → 70% of GB in one year and merchant bookings carry payments revenue on top of commission. Airbnb is already 100% merchant, so it has no equivalent mix tailwind; its levers are fee rate, Services/Experiences (higher %, small base) and FX. Expedia's is diluted by B2B (growing 24% but lower margin) and air.
3. **Diversification.** Airbnb ≈ one product, one fee. Booking has flights (tickets +39% YoY), cars, KAYAK/OpenTable ads. Expedia has a third of revenue in B2B wholesale plus advertising. A lodging-demand shock hits Airbnb's P&L one-for-one; the OTAs have partial offsets.
4. **Float is a real earnings line for Airbnb.** $705mm of FY25 interest income ≈ 28% of net income, and it fell from $818mm in FY24 as rates came down. Any model should treat this as rate-sensitive, not operating income. Booking/Expedia have float on merchant bookings only.
5. **Supplier bargaining.** Booking/Expedia negotiate commission and net rates with professional hoteliers (and hotels can retaliate with loyalty/direct pricing — see `hotel_loyalty_stickiness_vs_abnb.md`). Airbnb's supply is millions of individual hosts with little pricing power vs the platform, which is why it can push a uniform 15.5% globally.

## 4. Modeling notes for Krishang / Theo

- Model ABNB revenue as GBV × take rate, with take rate driven by (a) host-only fee mix, (b) FX (61% of revenue non-US), (c) Services/Experiences mix, and (d) booking-to-stay timing. Airbnb itself attributes the Q4'25 drop to FX and timing, not fee changes.
- Keep interest income below the operating line and tie it to funds held for customers ($6.96B) × a short-rate assumption.
- For comps: BKNG take rate benefits from payments revenue that ABNB already has embedded — so ABNB's 13.4% vs BKNG's 14.5% is roughly like-for-like on a merchant basis, while EXPE's 12.3% is not (B2B drag).
- If the team wants a "peer take-rate" sensitivity, ±50bp on ABNB's 13.4% is ≈ ±$460mm of FY25 revenue (on $91.3B GBV).

## Open items

- Pull FY2024 GBV for ABNB and FY2024 gross bookings for EXPE from the prior-year releases to complete the take-rate history (2019–2025) as a time series in `data/processed/`.
- Booking.com's actual blended commission rate is not disclosed; treat ~15% as an industry estimate, not a company figure.

## 5. Apples-to-apples: only the OTA segments that compete with Airbnb (added 2026-09-06)

Direct competitors are Booking.com's **alternative accommodations** (homes/apartments) and Expedia's **Vrbo**. Neither is a separately reported segment, so only partial disclosure exists.

| | Airbnb (stays) | Booking.com alt. accommodations | Vrbo (Expedia B2C) |
|---|---|---|---|
| Fee model | **Both.** Split fee: host 3% + guest 14.1–16.5% of subtotal. Host-only: 15.5%, mandatory for hotels, PMS-connected and some countries since Oct–Dec 2025. | **Host-only.** Property pays commission (~15% typical, 10–25% range), charged after checkout. Optional Payments by Booking.com adds ~1.1–3.1%. **Guest pays no service fee.** | **Split fee.** Host: 5% commission + 3% payment processing (3% waived if PMS handles payments); legacy $499–699/yr subscription closed to new hosts. **Guest: service fee 6–15% of subtotal**, "varies depending on the reservation amount." |
| All-in load on a $100 subtotal (approx.) | Split: ~$17–20. Host-only: $15.50 | ~$15–18 (all on host) | ~$14–23 (host $5–8 + guest $6–15) |
| Fee visible to guest at checkout? | Yes under split fee; no under host-only | No | Yes |
| Scale (FY2025) | 533.0M nights & seats booked; $91.3B GBV | ~36% of 1,235M room nights ≈ ~445M room nights; 8.6M listings; alt. accom. nights +10% FY25, +9% Q4 | Not disclosed (Expedia stopped breaking out Vrbo); B2C segment GB +5% in Q4'25 |

Sources: Airbnb fee schedule ([Airbnb Help 1857](https://www.airbnb.com/help/article/1857)); host-only rollout ([Hostfully simplified pricing](https://www.hostfully.com/blog/simplified-pricing-airbnb-vrbo-booking-com-single-fee-structures-for-vacation-rental-managers/)); Booking.com commission and no guest fee ([Booking.com Partner Help](https://partner.booking.com/en-us/help/commission-invoices-tax/commission/understanding-our-commission), [Wise](https://wise.com/us/blog/booking-com-host-fees), [Hospitable](https://hospitable.com/booking-com-host-fees)); Vrbo host and guest fees ([Hostfully Vrbo fees](https://www.hostfully.com/blog/vrbo-host-fees/), [Vrbo Help](https://help.vrbo.com/articles/What-is-the-service-fee)); Booking alt-accommodation mix 36%, 8.6M listings, growth ([BKNG Q4'25 call transcript](https://www.fool.com/earnings/call-transcripts/2026/02/18/booking-holdings-bkng-earnings-transcript/)); Vrbo/B2C Q4'25 ([Rental Scale-Up](https://www.rentalscaleup.com/vrbo-q4-2025-reliability-vs-airbnb/)); Airbnb and Booking unit figures ([ABNB Q4'25 letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter.pdf), [BKNG Q4'25 release](https://s201.q4cdn.com/865305287/files/doc_financials/2025/q4/Q4-25-BKNG-Earnings-Release.pdf)).

Read-through for the pitch:
- Airbnb's host-only migration copies **Booking.com**, not Vrbo. On a like-for-like host-only basis Airbnb (15.5%) charges roughly the same as Booking.com (~15% + payments fee) — so the migration is not obviously a take-rate cut vs the closest peer, but it removes Airbnb's guest-fee price advantage/disadvantage optics.
- Vrbo is the only peer still running a guest-facing split fee, and its total load can exceed Airbnb's. Vrbo is not the share threat; Booking.com is (445M alt-accom nights vs Airbnb's 533M, growing ~10% vs Airbnb nights +8%).
- Booking.com alt-accom nights at ~84% of Airbnb's volume is the number to put on a slide if the thesis is "Airbnb is losing the moat."

## 6. Event study: do BKNG / EXPE earnings move ABNB? (added 2026-09-06)

Method: next-trading-day reaction to each after-close report, Feb 2021–Aug 2026; market-adjusted returns (log return − β·QQQ, β_ABNB = 1.11). "Clean" = reporter volume ≥1.5× trailing median (date verified) and ABNB volume <2.5× (no own catalyst). Data: Yahoo Finance daily adjusted closes pulled in-browser; script `analysis/src/peer_earnings_event_study.js`; table `data/processed/peer_earnings_abnb_reaction.csv`; stats `analysis/src/peer_earnings_event_stats.py`.

| Reaction-day stat | BKNG prints | EXPE prints | Baseline |
|---|---|---|---|
| Clean events | 19 of 23 | 17 of 23 | 1,439 days |
| Corr (peer adj. move vs ABNB adj. move) | 0.04 (Spearman 0.04, p=0.88) | 0.57 (Spearman 0.50, p=0.04) | residual daily corr 0.36 / 0.38 |
| Slope (ABNB pts per 1pt peer) | 0.02 | 0.13 (0.16 on ≥5% prints, n=10, corr 0.66) | — |
| Same direction | 7/19 | 9/17 (6/10 on ≥5% prints) | — |
| Mean abs ABNB adj. move | 1.8% | 1.8% (2.4% on ≥5% prints) | 1.7% |
| Mean abs peer own move | 3.9% | 8.6% | — |

Daily co-movement: raw return correlation ABNB–BKNG 0.54, ABNB–EXPE 0.53, BKNG–EXPE 0.68; after stripping QQQ, 0.36 / 0.38.

Takeaways: Booking's print is noise for ABNB (no directional or volatility read-through). Expedia's print carries a modest read-through concentrated in outsized moves (≥5% → ~1–2% same-direction ABNB move), plausibly because Expedia's B2C/Vrbo/US mix is closer to Airbnb's demand than Booking's Europe/hotel/FX mix. Six Expedia events were dropped because Airbnb reported the same day or within a day — the calendars collide often. Caveats: n≈17–19, one-day windows only (3-day windows contaminated by ABNB's own reports), single full-period beta.

Earnings dates: MarketBeat ([BKNG](https://www.marketbeat.com/stocks/NASDAQ/BKNG/earnings/), [EXPE](https://www.marketbeat.com/stocks/NASDAQ/EXPE/earnings/)), [AlphaQuery BKNG](https://www.alphaquery.com/stock/BKNG/earnings-history); 2021–2024 EXPE dates verified by volume spike. Unverified/dropped dates: EXPE 2021-02-12, 2022-08-08 (no volume spike).
