# Hotel loyalty programs: how many guests are members, and is it really a moat vs. Airbnb?

*Prepared 2026-09-06 for the Citadel ABNB pitch. Every figure carries its source inline. Data tables: `data/processed/hotel_loyalty_programs.csv`, `data/processed/loyalty_stickiness_evidence.csv`. Chart: `research/notes/figures/loyalty_penetration.png` (script: `analysis/src/plot_loyalty_penetration.py`).*

## Bottom line

- **Membership is near-universal among big-brand hotel guests: ~2/3 of room nights are booked by loyalty members** (Marriott 68% global / 75% U.S.&Canada; Hilton "approaching 70%"; IHG 66%; Wyndham 53% of U.S. check-ins). That number is real and rising ~1–3 pts a year.
- **But "member" ≠ "loyal."** The average member stays **1.0 night per year** (CBRE), hotel programs score **53/100** on Skift's stickiness index (airlines 62–66), and hotel-loyalty members are **just as likely to stay at a non-member hotel as a member hotel** (Morning Consult, 17% vs 17%). Roughly half of memberships are inactive.
- **The real moat is financial, not behavioral.** Loyalty's durable edge is (1) the co-brand credit card annuity (Marriott: $716M in 2025 → ~$1B in 2026, +35–39%) and (2) cheaper direct distribution vs OTAs (IHG: members 10x more likely to book direct; member stays ~20% more profitable to owners than OTA stays). Neither of these takes demand away from Airbnb directly.
- **Where loyalty *does* bind demand — business transient and group (~55% of Marriott's room nights) — Airbnb barely competes. Where Airbnb competes — leisure (~45%) — loyalty is weakest** and travelers self-report choosing on price, amenities and cleaning fees, not points.
- **Pitch implication:** hotel loyalty is a legitimate but *overstated* bear point on ABNB. Frame it as a moat vs OTAs and a corporate-travel lock-in, not a wall against leisure/group share shift. Airbnb's own retention evidence (69% of revenue from repeat guests at IPO; 64% of nights on-app; NPS "strongest since the pandemic") is comparable without a points liability. The 2026 Airbnb loyalty launch is a live catalyst either way.

---

## 1. What share of hotel guests are in loyalty programs?

### Membership counts (latest disclosed)

| Program | Members | As of | Growth | Source |
|---|---|---|---|---|
| Marriott Bonvoy | 295M+ | Q2 2026 | 271M at YE2025; +43M added in 2025 | [Pulse2 (Q2'26)](https://pulse2.com/marriott-bonvoy-membership-tops-295-million-as-credit-card-fees-help-franchise-revenue-rise-19/); [Marriott Q4'25 release](https://www.prnewswire.com/news-releases/marriott-international-reports-fourth-quarter-and-full-year-2025-results-302683152.html) |
| Hilton Honors | 243M | YE2025 | +15% YoY; growing "15–20% a year" | [HLT 10-K summary](https://www.stocktitan.net/sec-filings/HLT/10-k-hilton-worldwide-holdings-inc-files-annual-report-aebd447ca003.html); [Q3'25 call](https://www.investing.com/news/transcripts/earnings-call-transcript-hilton-worldwide-beats-q3-2025-earnings-expectations-93CH-4302232) |
| IHG One Rewards | 160M+ | YE2025 | Enrolments +25% YoY | [IHG FY25 results](https://www.ihgplc.com/~/media/Files/I/Ihg-Plc/results/2026/full-year-2025/full-year-results-for-the-year-to-31-dec-2025.pdf) |
| Wyndham Rewards | 122M+ | YE2025 | +7% YoY; +24% since YE2022 | [WH 10-K summary](https://www.stocktitan.net/sec-filings/WH/10-k-wyndham-hotels-resorts-inc-files-annual-report-e42a090dbdbb.html) |
| Choice Privileges | 70M+ | Q1 2025 | +8% YoY | [CHH Q1'25 call](https://www.marketbeat.com/earnings/reports/2025-5-8-choice-hotels-international-inc-stock) |
| World of Hyatt | 63M+ | YE2025 | 56M at Q1'25, +22% YoY | [Hyatt PR Jan-2026](https://www.businesswire.com/news/home/20260126283630/en); [H Q1'25 call](https://www.marketbeat.com/earnings/reports/2025-5-1-hyatt-hotels-co-stock) |
| Accor ALL | 99M | Feb 2025 | — | [View from the Wing / Skift](https://viewfromthewing.com/forget-marriott-and-hilton-hyatt-and-an-unexpected-challenger-are-winning-hotel-loyalty/) |
| CBRE aggregate (MAR+HLT+WH+CHH) | 675M | 2024 | +14.5% YoY; **137 members per available room** | [CBRE](https://www.cbre.com/insights/articles/hotel-loyalty-programs-continue-to-prove-their-value-key-findings-from-675-million-members) |

Caveat: these are database records, not deduplicated people. Nobody discloses active-member counts ([VFTW/Skift](https://viewfromthewing.com/forget-marriott-and-hilton-hyatt-and-an-unexpected-challenger-are-winning-hotel-loyalty/); [Hotel Online](https://www.hotel-online.com/news/hotel-guests-have-never-been-more-disloyal-but-some-brands-get-it)). Hilton's last disclosure put active members at ">50% of global membership" in 2019, up from 15–20% around 2013 ([TPG](https://thepointsguy.com/news/hilton-big-surge-membership-and-engagement/)).

### Penetration: share of room nights booked by members (the number that matters)

| Program | Member share | Scope / period | Trend | Source |
|---|---|---|---|---|
| Marriott Bonvoy | **68%** global / **75%** U.S.&Canada | FY2025 room nights | 58% at Bonvoy launch (2019) | [Q4'25 release](https://www.prnewswire.com/news-releases/marriott-international-reports-fourth-quarter-and-full-year-2025-results-302683152.html); [Q4'25 call](https://www.fool.com/earnings/call-transcripts/2026/02/10/marriott-mar-q4-2025-earnings-call-transcript/) |
| Hilton Honors | **"approaching 70%"** of occupancy | Q3 2025 | ~60% in 2018; multi-year target 75% | [Q3'25 call (Nassetta)](https://www.investing.com/news/transcripts/earnings-call-transcript-hilton-worldwide-beats-q3-2025-earnings-expectations-93CH-4302232); [TPG 2019](https://thepointsguy.com/news/hilton-honors-membership-surge-earnings/) |
| IHG One Rewards | **66%** of room nights | FY2025 | +3 pts in every region in 2025; >60% global / ~70% Americas in 2023 | [IHG FY25](https://www.ihgplc.com/~/media/Files/I/Ihg-Plc/results/2026/full-year-2025/full-year-results-for-the-year-to-31-dec-2025.pdf); [PhocusWire](https://www.phocuswire.com/ihg-loyalty-program-attribute-based-selling) |
| Wyndham Rewards | **53%** of U.S. check-ins / 37% global | FY2025 | — | [WH 10-K](https://www.stocktitan.net/sec-filings/WH/10-k-wyndham-hotels-resorts-inc-files-annual-report-e42a090dbdbb.html) |
| World of Hyatt | not disclosed as % | Q1 2025 | penetration +170 bps YoY | [H Q1'25 call](https://www.marketbeat.com/earnings/reports/2025-5-1-hyatt-hotels-co-stock) |
| CBRE 4-company aggregate | **52.8%** of occupied room nights | 2024 | — | [CBRE](https://www.cbre.com/insights/articles/hotel-loyalty-programs-continue-to-prove-their-value-key-findings-from-675-million-members) |
| *OTA comparator:* Booking.com Genius L2–3 | >50% of room nights from ~30% of active users | Q3 2025 | — | [Hospitality.today](https://www.hospitality.today/article/genius-members-drive-over-half-of-booking-com-bookings) |

**Answer to the headline question: ~65–75% of nights at the big U.S. brands are booked by members; economy brands (Wyndham) ~50%.** Note that "member" includes someone who signed up at check-in to get the member rate or Wi-Fi, so penetration overstates attachment.

---

## 2. Is it actually sticky? Evidence on both sides

### Evidence that loyalty binds behavior (bull case for hotels)

- **Members out-spend and out-stay non-members.** IHG: members spend ~20% more and are ~10x more likely to book direct ([IHG FY25](https://www.ihgplc.com/~/media/Files/I/Ihg-Plc/results/2026/full-year-2025/full-year-results-for-the-year-to-31-dec-2025.pdf)). Hyatt: members stay 62% more often and spend 93% more; 50+-night members +13% in 2025 ([Hyatt](https://www.businesswire.com/news/home/20260126283630/en)). Choice: members 6x more likely to book brand-direct, 90% more room nights/yr ([CHH](https://www.marketbeat.com/earnings/reports/2025-5-8-choice-hotels-international-inc-stock)). IHG U.S. cardholders stay 85% more and spend 35% more than non-cardholder members ([PhocusWire](https://www.phocuswire.com/ihg-loyalty-program-attribute-based-selling)). *Caveat: heavy selection bias — frequent travelers join programs; programs don't create frequent travelers.*
- **Direct-channel economics.** IHG gets 80% of room revenue through its own channels; a member stay costs ~50% less to acquire than an OTA stay and is ~20% more profitable to the owner ([PhocusWire](https://www.phocuswire.com/ihg-loyalty-program-attribute-based-selling)). This is the moat vs. Booking/Expedia — not vs. Airbnb.
- **Stated preference.** 87% of GHA members say they'd pick a hotel with a global loyalty program over one without; 79% book through the program's site/app ([Skift/GHA 2026](https://skift.com/2026/04/17/gha-2026-loyalty-report/)). 60% of U.S. loyalty members consider points when deciding where/when to travel ([Morning Consult via Hotel Dive](https://www.hoteldive.com/news/travel-loyalty-programs-stagnate-report/736400/)).
- **The card annuity is huge and growing faster than the hotels.** Marriott co-brand card fees: $716M in 2025 (+8%), guided +35% → "high-30s%" for 2026 (~$1B), with new Chase/Amex deals adding $100–125M by 2028 at a 26% royalty rate ([Q4'25 call](https://www.fool.com/earnings/call-transcripts/2026/02/10/marriott-mar-q4-2025-earnings-call-transcript/); [Q2'26 call](https://www.fool.com/earnings/call-transcripts/2026/08/10/marriott-mar-q2-2026-earnings-call-transcript/); [Skift](https://skift.com/2026/06/16/marriott-hotel-owners-want-a-bigger-cut-of-loyalty-income/)). IHG card fees ~doubled 2023→2025 from $39M and are guided to >3x by 2028 ([IHG FY25](https://www.ihgplc.com/~/media/Files/I/Ihg-Plc/results/2026/full-year-2025/full-year-results-for-the-year-to-31-dec-2025.pdf)). Marriott's loyalty liability is $8.0B (YE2025) / $8.2B (Mar-2026) ([MAR 10-Q](https://www.sec.gov/Archives/edgar/data/1048286/000104828626000014/mar-20260331.htm)) — that is pre-funded future hotel demand that Airbnb cannot access.

### Evidence that it's broad but shallow (bull case for ABNB)

- **Stays per member are collapsing.** Room nights per member fell to **1.0 in 2024** from 1.1 in 2023 and **1.8 in 2016**, even as memberships grew 14.5% — programs are adding sign-ups faster than stays ([CBRE](https://www.cbre.com/insights/articles/hotel-loyalty-programs-continue-to-prove-their-value-key-findings-from-675-million-members)).
- **Hotel loyalty leaks far more than airline loyalty.** Skift's Loyalty Stickiness Index: hotels **53/100** vs airlines 62–66 (100 = always book inside your main program); convenience/location, not price or rewards, drives straying ([Skift Research, 2025](https://skift.com/2025/09/23/loyalty-stickiness-index-shows-big-leaks-why-your-travelers-stray/)).
- **Members don't behave loyally.** In Morning Consult's Oct-2024 survey (n=4,450), **17% of hotel-loyalty members stayed at non-member hotels 2+ times in the past year — the same 17% that stayed at member hotels 2+ times**; airline equivalent is 9%. Travel-loyalty membership has been flat since 2021 in every demographic, and only 43% of members feel the program makes them feel valued ([Hotel Dive](https://www.hoteldive.com/news/travel-loyalty-programs-stagnate-report/736400/)).
- **Everyone is in everyone's program.** Travelers are now active in 3–4 hotel programs, up from 2–3 ([Skift/GHA](https://skift.com/2026/04/17/gha-2026-loyalty-report/)); the average U.S. consumer holds 17.9 loyalty memberships and uses ~half ([Bond via eMarketer](https://www.emarketer.com/content/consumers-use-half-of-loyalty-programs-they-belong)). Multi-homing means "member" carries no exclusivity.
- **Loyalty is treated as a coupon, not a relationship.** 40% of travelers see loyalty as a "financial optimization tool" (45% of Gen Z/millennials); **56% say they'd shift to price and convenience if programs disappeared**; ~75% have hit a redemption failure ([iSeatz via CX Dive, 2026](https://www.customerexperiencedive.com/news/financial-perks-top-draw-of-travel-loyalty-stickiness/825453/)).
- **Points don't show up in the hotel-vs-Airbnb decision.** In UpgradedPoints' Oct-2025 survey (n=2,193), 61–62% prefer hotels — for amenities (73%), no cleaning rules/fees (62%) and easy booking/cancellation (52%). Loyalty points are not among the cited reasons ([UpgradedPoints](https://upgradedpoints.com/news/airbnb-vs-hotels-traveler-survey/)). Alchemer's June-2026 study (n=1,014) finds **vacation-rental guests are more loyal than hotel guests: NPS 50.9 vs 41.8**, with under-30s tilting to rentals and 64% of 61+ mostly booking hotels ([Alchemer](https://www.alchemer.com/resources/blog/alchemer-study-vacation-rentals-surpass-hotels-in-guest-loyalty-as-traveler-preferences-shift-across-generations/)).
- **The program is getting more expensive to run and owners are revolting.** Loyalty fees grew 4.4% vs 2.7% total revenue in 2024 ([CBRE](https://www.cbre.com/insights/articles/hotel-loyalty-programs-continue-to-prove-their-value-key-findings-from-675-million-members)); in June 2026, 51 owners representing ~1,000 Marriott hotels demanded a share of card income ([Skift](https://skift.com/2026/06/16/marriott-hotel-owners-want-a-bigger-cut-of-loyalty-income/)).

---

## 3. Airbnb's side of the ledger (no points, but real retention)

| Metric | Value | Period | Source |
|---|---|---|---|
| Revenue from repeat guests | **69%** | 2019 | [S-1](https://www.sec.gov/Archives/edgar/data/1559720/000119312520294801/d81668ds1.htm) |
| Traffic direct or unpaid | **91%** (company still cites ~90%) | 9M 2020 | [S-1](https://www.sec.gov/Archives/edgar/data/1559720/000119312520294801/d81668ds1.htm); [Skift Aug-2026](https://skift.com/2026/08/17/airbnb-has-quietly-rebuilt-the-marketing-engine-it-was-famous-for-cutting/) |
| Nights booked on the app | **64%** (59% a year earlier); app nights +23% YoY | Q2 2026 | [Q2'26 call](https://www.fool.com/earnings/call-transcripts/2026/08/13/airbnb-abnb-q2-2026-earnings-call-transcript/) |
| " | 58% (53%) | Q3 2024 | [Q3'24 letter](https://s26.q4cdn.com/656283129/files/doc_financials/2024/q3/Airbnb_Q3-2024-Shareholder-Letter_Final.pdf) |
| Guest Favorites share of bookings | "nearly half" | Q4 2025 | [Q4'25 call](https://www.fool.com/earnings/call-transcripts/2026/02/12/airbnb-abnb-q4-2025-earnings-call-transcript/) |
| NPS | "strongest since the pandemic by far, and accelerating" | Q4 2025 | [Q4'25 call](https://www.fool.com/earnings/call-transcripts/2026/02/12/airbnb-abnb-q4-2025-earnings-call-transcript/) |
| Hotel bookers who come back to book a home within 365 days | 55% | Q1 2026 | [Q1'26 results](https://news.airbnb.com/airbnb-q1-2026-financial-results/) |
| First-time hotel guests who return to book a home within a year | ~35% | Q2 2026 | [Q2'26 call](https://www.fool.com/earnings/call-transcripts/2026/08/13/airbnb-abnb-q2-2026-earnings-call-transcript/) |
| Sales & marketing | $2.59B, +20% YoY on revenue +10% ($12.2B) | FY2025 | [Q4'25 letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter-Final.pdf) |
| Brand + performance marketing growth vs revenue growth | +32% vs +17% | H1 2026 | [Skift](https://skift.com/2026/08/17/airbnb-has-quietly-rebuilt-the-marketing-engine-it-was-famous-for-cutting/) |

Watch-outs for the bear side: the "90% direct" claim has been static since 2020 while marketing dollars quadrupled ($119M → $512M/quarter brand+performance, Q1'21 → Q1'26) ([Hospitality.today](https://www.hospitality.today/article/the-direct-booking-success-story-hotels-were-told-to-copy-is-buying-traffic-again)), and the 69%-repeat figure is a 2019 disclosure that has not been refreshed.

**Airbnb's loyalty stance.** Chesky (May 2025): "a loyalty program is what you create when you don't have loyalty" — exploring a paid Prime-style membership rather than points ([TPG](https://thepointsguy.com/news/airbnb-loyalty-rewards-membership-program/)). Q4'25 call: "if we do a loyalty program, we wouldn't want to do an out-of-the-box points program"; benefits are in testing and will be packaged before launch ([Q4'25 call](https://www.fool.com/earnings/call-transcripts/2026/02/12/airbnb-abnb-q4-2025-earnings-call-transcript/)); trade press expects a launch later in 2026 ([TTW](https://www.travelandtourworld.com/news/article/brian-chesky-reveals-airbnbs-loyalty-program-tests-major-growth-ahead-for-the-travel-platform/)). No launch as of the Q2'26 call (Aug 13, 2026).

---

## 4. So is it a strong advantage vs. Airbnb? Segment by segment

Marriott's 2025 room-night mix: ~45% leisure, ~25% group, ~30% business transient ([Q4'25 call](https://www.fool.com/earnings/call-transcripts/2026/02/10/marriott-mar-q4-2025-earnings-call-transcript/)).

| Segment | Loyalty grip | Airbnb overlap | Read |
|---|---|---|---|
| Business transient (~30%) | Strong: corporate rate programs, expense policy, status chasing, card spend | Low (Airbnb for Work is small; hotels on Airbnb single-digit % of nights) | Loyalty defends demand Airbnb wasn't going to win |
| Group / meetings (~25%) | Strong (contracted blocks) | ~None | Same |
| Leisure (~45%) | Weakest: stickiness 53/100, leisure travelers price/amenity-driven, 56% would switch on price | High — this is Airbnb's core | Loyalty is not what keeps leisure guests in hotels; amenities, fees, and trust are |

Implications for the pitch:

1. **Don't concede "loyalty moat" as a broad bear point.** Quantify it: loyalty's binding power sits in the ~55% of hotel nights (business + group) where Airbnb has minimal share. In leisure, the survey and CBRE data say members behave like free agents.
2. **The moat that matters is the card.** Co-brand economics (~$1B/yr for Marriott alone, growing 35%+) fund promotions and points that subsidize hotel leisure stays. This is the channel through which loyalty can *indirectly* pull leisure demand from Airbnb — worth modeling as a "points-funded free-night" effect rather than a behavioral lock-in.
3. **Airbnb's retention is arguably comparable at zero liability.** 64% of nights via the app and a 2019-vintage 69% repeat-revenue share vs hotels' 1.0 nights per member. If the team wants a killer stat: hotels carry an $11.6B loyalty IOU across seven groups ([Yahoo Finance](https://finance.yahoo.com/markets/stocks/articles/7-billion-loyalty-iou-marriott-130000589.html)); Airbnb's equivalent liability is $0.
4. **Catalyst either direction:** the 2026 Airbnb loyalty/membership launch. Bulls: closes the one gap hotels cite; bears: a costly copy of a program with 53/100 stickiness.
5. **Counter-argument to keep honest:** hotel penetration keeps climbing (+1–3 pts/yr) and card fees compound; the hotels are getting *better* at this, and Marriott's US&Canada 75% shows a ceiling still well above Airbnb's markets.

## Open items / next data pulls

- Hilton and Hyatt do not disclose penetration as a hard %; Hyatt discloses only the bps change. Try Hilton's investor day deck if one lands before Oct 2.
- Airbnb's repeat-guest share hasn't been re-disclosed since the S-1 — worth asking IR or checking the 2025 10-K risk-factor language.
- CBRE's figures aggregate MAR+HLT+WH+CHH only (no IHG/Hyatt).
