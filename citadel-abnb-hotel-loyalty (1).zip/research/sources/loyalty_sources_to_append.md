# Sources added 2026-09-06 — hotel loyalty stickiness vs ABNB (append to research/sources/README.md)

| Source | Used for | URL |
|---|---|---|
| Marriott Q4 2025 results release (Feb 2026) | 271M Bonvoy members; 68% global / 75% US&Can member room nights; +35% card-fee guide | https://www.prnewswire.com/news-releases/marriott-international-reports-fourth-quarter-and-full-year-2025-results-302683152.html |
| Marriott Q4 2025 earnings call (Motley Fool transcript) | $716M card fees; 58%→68% penetration; segment mix 45/25/30 | https://www.fool.com/earnings/call-transcripts/2026/02/10/marriott-mar-q4-2025-earnings-call-transcript/ |
| Marriott Q2 2026 earnings call | 295M members; Chase/Amex deals $100–125M by 2028 at 26% royalty | https://www.fool.com/earnings/call-transcripts/2026/08/10/marriott-mar-q2-2026-earnings-call-transcript/ |
| Marriott 10-Q Q1 2026 | Loyalty liability $7,992M (YE25) / $8,198M (Mar-26) | https://www.sec.gov/Archives/edgar/data/1048286/000104828626000014/mar-20260331.htm |
| Hilton Q3 2025 earnings call (Investing.com transcript) | "approaching 70%" Honors occupancy; 75% target; 15–20% growth | https://www.investing.com/news/transcripts/earnings-call-transcript-hilton-worldwide-beats-q3-2025-earnings-expectations-93CH-4302232 |
| Hilton 2025 10-K (StockTitan summary) | 243M members, +15% | https://www.stocktitan.net/sec-filings/HLT/10-k-hilton-worldwide-holdings-inc-files-annual-report-aebd447ca003.html |
| IHG FY2025 results | 160M members; 66% penetration; members spend ~20% more, 10x direct; card fees ~2x since 2023 | https://www.ihgplc.com/~/media/Files/I/Ihg-Plc/results/2026/full-year-2025/full-year-results-for-the-year-to-31-dec-2025.pdf |
| PhocusWire on IHG (2024) | 80% own-channel revenue; member vs OTA guest economics | https://www.phocuswire.com/ihg-loyalty-program-attribute-based-selling |
| Wyndham 2025 10-K (StockTitan summary) | 122M members; 53% US / 37% global check-ins | https://www.stocktitan.net/sec-filings/WH/10-k-wyndham-hotels-resorts-inc-files-annual-report-e42a090dbdbb.html |
| Hyatt PR Jan 2026 / Q1 2025 call | 63M members; +62% stays, +93% spend; +170bps penetration | https://www.businesswire.com/news/home/20260126283630/en ; https://www.marketbeat.com/earnings/reports/2025-5-1-hyatt-hotels-co-stock |
| Choice Q1 2025 call | 70M members; 6x direct; 90% more nights | https://www.marketbeat.com/earnings/reports/2025-5-8-choice-hotels-international-inc-stock |
| CBRE Hotels Research (2025) | 675M memberships; 52.8% occupancy; 1.0 nights/member; 137 members/room | https://www.cbre.com/insights/articles/hotel-loyalty-programs-continue-to-prove-their-value-key-findings-from-675-million-members |
| Skift Research Loyalty Stickiness Index (Sep 2025) | Hotels 53/100 vs airlines 62–66 | https://skift.com/2025/09/23/loyalty-stickiness-index-shows-big-leaks-why-your-travelers-stray/ |
| Morning Consult via Hotel Dive (Dec 2024) | 17% vs 17% defection; flat membership; 43% feel valued; 60% consider points | https://www.hoteldive.com/news/travel-loyalty-programs-stagnate-report/736400/ |
| iSeatz via CX Dive (2026) | 40% financial-optimization; 56% would switch; 75% redemption failure | https://www.customerexperiencedive.com/news/financial-perks-top-draw-of-travel-loyalty-stickiness/825453/ |
| Skift / GHA 2026 loyalty report | 87% prefer hotel with program; 3–4 programs; 79% book direct | https://skift.com/2026/04/17/gha-2026-loyalty-report/ |
| Bond Brand Loyalty via eMarketer (2023) | 17.9 memberships, ~50% active | https://www.emarketer.com/content/consumers-use-half-of-loyalty-programs-they-belong |
| UpgradedPoints survey (Oct 2025) | 61–62% prefer hotels; reasons exclude points | https://upgradedpoints.com/news/airbnb-vs-hotels-traveler-survey/ |
| Alchemer 2026 hospitality benchmarks | NPS rentals 50.9 vs hotels 41.8 | https://www.alchemer.com/resources/blog/alchemer-study-vacation-rentals-surpass-hotels-in-guest-loyalty-as-traveler-preferences-shift-across-generations/ |
| Skift, Marriott owners & loyalty income (Jun 2026) | 51 owners / ~1,000 hotels; ~$1B card fees 2026 | https://skift.com/2026/06/16/marriott-hotel-owners-want-a-bigger-cut-of-loyalty-income/ |
| Yahoo Finance, "$7B loyalty IOU" | $11.6B liabilities across 7 groups | https://finance.yahoo.com/markets/stocks/articles/7-billion-loyalty-iou-marriott-130000589.html |
| Airbnb S-1 (2020) | 69% repeat-guest revenue (2019); 91% direct/unpaid traffic | https://www.sec.gov/Archives/edgar/data/1559720/000119312520294801/d81668ds1.htm |
| Airbnb Q4 2025 shareholder letter | FY25 S&M $2.588B; revenue $12.2B; app 64% | https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter-Final.pdf |
| Airbnb Q4 2025 / Q2 2026 calls (Motley Fool) | loyalty stance; NPS; hotel→home conversion; app 64% | https://www.fool.com/earnings/call-transcripts/2026/02/12/airbnb-abnb-q4-2025-earnings-call-transcript/ ; https://www.fool.com/earnings/call-transcripts/2026/08/13/airbnb-abnb-q2-2026-earnings-call-transcript/ |
| Airbnb Q1 2026 results | 55% of hotel bookers book a home within 365 days | https://news.airbnb.com/airbnb-q1-2026-financial-results/ |
| TPG interview with Chesky (May 2025) | "a loyalty program is what you create when you don't have loyalty" | https://thepointsguy.com/news/airbnb-loyalty-rewards-membership-program/ |
| Skift, Airbnb marketing engine (Aug 2026) | B+P marketing +32% vs revenue +17% H1'26 | https://skift.com/2026/08/17/airbnb-has-quietly-rebuilt-the-marketing-engine-it-was-famous-for-cutting/ |
| Hospitality.today on Airbnb direct traffic | $119M→$512M quarterly marketing | https://www.hospitality.today/article/the-direct-booking-success-story-hotels-were-told-to-copy-is-buying-traffic-again |
| Booking Holdings via Hospitality.today | Genius L2–3 >50% of room nights | https://www.hospitality.today/article/genius-members-drive-over-half-of-booking-com-bookings |
| TPG on Hilton (2019) | >50% active members; 60% occupancy 2018 | https://thepointsguy.com/news/hilton-big-surge-membership-and-engagement/ ; https://thepointsguy.com/news/hilton-honors-membership-surge-earnings/ |
| Upgraded Points, "Airbnb vs. Hotels: Where Do Travelers Want To Stay?" (n=2,193, Oct 2025; updated May 2026) | preference splits, reasons, cost perception, housing/regulation, state outliers | https://upgradedpoints.com/news/airbnb-vs-hotels-traveler-survey/ |
| Alchemer, 2026 Hospitality Benchmarks: Hotels vs. Vacation Rentals (n=1,014, June 2026) | NPS, promoters/detractors, age preference, experience drivers, Gen Z vs 61+, feedback loop | https://www.alchemer.com/resources/benchmark-report/2026-hospitality-benchmarks-hotels-vs-rentals/ |
