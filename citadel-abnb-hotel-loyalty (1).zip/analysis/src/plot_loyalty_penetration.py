"""Hotel loyalty penetration vs. engagement depth.

Left panel: share of room nights (or check-ins) booked by loyalty members, by program.
Right panel: CBRE's room-nights-per-member series — the "broad but shallow" counterpoint.

Reads data/processed/hotel_loyalty_programs.csv; writes research/notes/figures/loyalty_penetration.png.
Run from repo root:  python analysis/src/plot_loyalty_penetration.py
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data/processed/hotel_loyalty_programs.csv"
OUT = ROOT / "research/notes/figures/loyalty_penetration.png"

SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e6e5e1"
BLUE, ORANGE = "#2a78d6", "#eb6834"

df = pd.read_csv(DATA)
pen = df.dropna(subset=["member_share_of_room_nights_pct"]).copy()
pen = pen[~pen["program"].str.startswith("Booking.com")]  # OTA comparator, different denominator
pen["label"] = pen["program"].str.replace(" (MAR+HLT+WH+CHH)", "", regex=False)
pen = pen.sort_values("member_share_of_room_nights_pct")

# Add Marriott U.S.&Canada as its own bar (disclosed alongside the global figure).
extra = pd.DataFrame([{"label": "Marriott Bonvoy (U.S. & Canada)", "member_share_of_room_nights_pct": 75}])
pen = pd.concat([pen[["label", "member_share_of_room_nights_pct"]], extra]).sort_values("member_share_of_room_nights_pct")

# CBRE room nights per member (2016, 2023, 2024)
cbre = pd.DataFrame({"year": [2016, 2023, 2024], "nights_per_member": [1.8, 1.1, 1.0]})

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.8), gridspec_kw={"width_ratios": [1.6, 1]})
fig.patch.set_facecolor(SURFACE)

# --- Left: penetration bars ---
ax1.set_facecolor(SURFACE)
bars = ax1.barh(pen["label"], pen["member_share_of_room_nights_pct"], color=BLUE, height=0.55)
for b, v in zip(bars, pen["member_share_of_room_nights_pct"]):
    ax1.text(v + 1, b.get_y() + b.get_height() / 2, f"{v:.0f}%", va="center", color=INK, fontsize=10)
ax1.set_xlim(0, 100)
ax1.set_xlabel("Share of room nights / occupancy booked by loyalty members", color=INK2)
ax1.set_title("Loyalty members drive ~2/3 of big-brand hotel room nights", loc="left", color=INK, fontsize=12, fontweight="bold")
ax1.xaxis.grid(True, color=GRID, linewidth=0.8)
ax1.set_axisbelow(True)
for s in ("top", "right", "left"):
    ax1.spines[s].set_visible(False)
ax1.spines["bottom"].set_color(GRID)
ax1.tick_params(colors=INK2, length=0)
for t in ax1.get_yticklabels():
    t.set_color(INK)

# --- Right: nights per member ---
ax2.set_facecolor(SURFACE)
xs = range(len(cbre))
ax2.bar(xs, cbre["nights_per_member"], color=ORANGE, width=0.5)
for x, y in zip(xs, cbre["nights_per_member"]):
    ax2.text(x, y + 0.05, f"{y:.1f}", ha="center", color=INK, fontsize=10)
ax2.set_ylim(0, 2.2)
ax2.set_xticks(list(xs))
ax2.set_xticklabels(cbre["year"].astype(str))
ax2.set_ylabel("Room nights per member per year", color=INK2)
ax2.set_title("…but stays per member keep falling", loc="left", color=INK, fontsize=12, fontweight="bold")
ax2.yaxis.grid(True, color=GRID, linewidth=0.8)
ax2.set_axisbelow(True)
for s in ("top", "right"):
    ax2.spines[s].set_visible(False)
for s in ("left", "bottom"):
    ax2.spines[s].set_color(GRID)
ax2.tick_params(colors=INK2, length=0)

fig.text(0.01, 0.01,
         "Sources: Marriott Q4'25 release (FY25); Hilton Q3'25 call ('approaching 70%'); IHG FY25 results; Wyndham FY25 10-K (U.S. check-ins); "
         "CBRE Hotels Research (MAR+HLT+WH+CHH aggregate, 2024).",
         color=INK2, fontsize=7.5)
fig.tight_layout(rect=(0, 0.04, 1, 1))
OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, dpi=180, facecolor=SURFACE)
print(f"wrote {OUT}")
