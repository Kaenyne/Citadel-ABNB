"""Event study: how ABNB trades around hotel-industry prints and events.

NOT RUN in the cloud session (price APIs blocked) - run locally:
    pip install yfinance pandas numpy
    python analysis/src/hotel_abnb_event_study.py

Outputs (data/processed/):
    abnb_hotel_event_returns.csv   - ABNB, MAR, HLT, H, SPY returns in [-1,+1] and [0,+3] windows
                                     around each event in hotel_events_timeline.csv, plus ABNB's
                                     market-adjusted (vs SPY) and hotel-adjusted (vs avg MAR/HLT/H) return
    abnb_hotel_rolling_corr.csv    - 60d rolling correlation of daily returns ABNB vs hotel basket and vs SPY
    abnb_hotel_beta.csv            - full-sample and yearly OLS beta of ABNB on hotel basket (controlling for SPY)

Interpretation guide:
    * hotel-adjusted return << 0 on a hotel *beat* day  -> market treats hotels as taking share from ABNB (bear case)
    * hotel-adjusted return ~ 0, market-adjusted > 0    -> same macro trade (travel beta), no substitution signal
    * rolling corr falling while both grow              -> decoupling (2026 thesis: ABNB = hotel distributor, not victim)
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
EVENTS = ROOT / "data/processed/hotel_events_timeline.csv"
OUTDIR = ROOT / "data/processed"
TICKERS = ["ABNB", "MAR", "HLT", "H", "SPY"]
HOTELS = ["MAR", "HLT", "H"]


def load_prices(start="2020-12-10"):
    import yfinance as yf  # local only

    px = yf.download(TICKERS, start=start, auto_adjust=True, progress=False)["Close"]
    return px.dropna(how="all")


def window_return(px, t0, a, b):
    """Cumulative return from close at trading day t0+a-1 to close at t0+b (a<=0<=b)."""
    idx = px.index
    pos = idx.searchsorted(pd.Timestamp(t0))
    if pos >= len(idx):
        return np.nan
    lo, hi = pos + a - 1, pos + b
    if lo < 0 or hi >= len(idx):
        return np.nan
    return px.iloc[hi] / px.iloc[lo] - 1


def main():
    px = load_prices()
    ev = pd.read_csv(EVENTS, parse_dates=["date"])
    ev = ev[ev["date"] >= px.index.min()]  # ABNB listed Dec 10, 2020

    rows = []
    for _, e in ev.iterrows():
        r = {"date": e["date"].date(), "event": e["event"], "category": e["category"]}
        for tk in TICKERS:
            r[f"{tk}_m1p1"] = window_return(px[tk], e["date"], -1, 1)
            r[f"{tk}_0p3"] = window_return(px[tk], e["date"], 0, 3)
        hb = np.nanmean([r[f"{t}_m1p1"] for t in HOTELS])
        r["hotel_basket_m1p1"] = hb
        r["abnb_mkt_adj_m1p1"] = r["ABNB_m1p1"] - r["SPY_m1p1"]
        r["abnb_hotel_adj_m1p1"] = r["ABNB_m1p1"] - hb
        rows.append(r)
    pd.DataFrame(rows).to_csv(OUTDIR / "abnb_hotel_event_returns.csv", index=False)

    ret = px.pct_change().dropna()
    basket = ret[HOTELS].mean(axis=1)
    rc = pd.DataFrame({
        "corr_abnb_hotels_60d": ret["ABNB"].rolling(60).corr(basket),
        "corr_abnb_spy_60d": ret["ABNB"].rolling(60).corr(ret["SPY"]),
    })
    rc.to_csv(OUTDIR / "abnb_hotel_rolling_corr.csv")

    def beta(df):
        X = np.column_stack([np.ones(len(df)), df["hotels"], df["SPY"]])
        b = np.linalg.lstsq(X, df["ABNB"], rcond=None)[0]
        return pd.Series({"beta_hotels": b[1], "beta_spy": b[2], "n": len(df)})

    d = pd.DataFrame({"ABNB": ret["ABNB"], "hotels": basket, "SPY": ret["SPY"]}).dropna()
    out = d.groupby(d.index.year).apply(beta)
    out.loc["full"] = beta(d)
    out.to_csv(OUTDIR / "abnb_hotel_beta.csv")
    print(out)


if __name__ == "__main__":
    main()
