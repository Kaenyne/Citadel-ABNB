"""Grouped bar chart: Marriott US&Canada RevPAR growth vs Airbnb nights & seats growth, by quarter.

Input : data/processed/hotel_vs_abnb_quarterly_kpis.csv
Output: docs/figures/hotel_vs_abnb_growth.png

Run from repo root:  python analysis/src/plot_hotel_vs_abnb.py
"""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "data/processed/hotel_vs_abnb_quarterly_kpis.csv"
OUT = ROOT / "docs/figures/hotel_vs_abnb_growth.png"

# palette (dataviz reference instance, light mode)
SURFACE, INK, INK2, MUTED, GRID, BASE = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
S1, S2 = "#2a78d6", "#eb6834"  # slot 1 blue = hotels, slot 2 orange = Airbnb

df = pd.read_csv(SRC)
q = df["quarter"].tolist()
hot = df["mar_us_canada_revpar_yoy_pct"].astype(float)
abn = df["abnb_nights_seats_yoy_pct"].astype(float)

fig, ax = plt.subplots(figsize=(9, 4.6), dpi=200)
fig.patch.set_facecolor(SURFACE)
ax.set_facecolor(SURFACE)

x = range(len(q))
w = 0.36
gap = 0.02
b1 = ax.bar([i - w / 2 - gap / 2 for i in x], hot, w, color=S1, label="Marriott US & Canada RevPAR (YoY %)", zorder=3)
b2 = ax.bar([i + w / 2 + gap / 2 for i in x], abn, w, color=S2, label="Airbnb nights & seats booked (YoY %)", zorder=3)

ax.axhline(0, color=BASE, lw=1, zorder=2)
ax.yaxis.grid(True, color=GRID, lw=0.8, zorder=1)
ax.set_axisbelow(True)
for s in ("top", "right", "left"):
    ax.spines[s].set_visible(False)
ax.spines["bottom"].set_color(BASE)
ax.set_xticks(list(x))
ax.set_xticklabels(q, color=MUTED, fontsize=9)
ax.tick_params(axis="y", colors=MUTED, labelsize=9, length=0)
ax.set_ylabel("Year-over-year growth, %", color=INK2, fontsize=9)
ax.set_ylim(-3, 12.5)

# selective direct labels: endpoints only
for bars, vals in ((b1, hot), (b2, abn)):
    for i in (0, len(vals) - 1):
        v = vals.iloc[i]
        ax.annotate(f"{v:+.1f}%" if bars is b1 else f"{v:+.0f}%", (bars[i].get_x() + bars[i].get_width() / 2, v),
                    xytext=(0, 4 if v >= 0 else -11), textcoords="offset points", ha="center", fontsize=8, color=INK2)

# shade the shutdown quarter
ax.axvspan(3 - 0.5, 3 + 0.5, color=GRID, alpha=0.5, zorder=0)
ax.text(3, 11.6, "43-day govt\nshutdown", ha="center", va="top", fontsize=7.5, color=INK2)

ax.set_title("Airbnb grew through the 2025 hotel down-cycle; both re-accelerated in 2026",
             loc="left", fontsize=11, color=INK, pad=14)
ax.legend(loc="upper left", frameon=False, fontsize=8, labelcolor=INK2, ncol=1, bbox_to_anchor=(0, 0.98))
fig.text(0.01, 0.01, "Sources: Marriott quarterly releases (US & Canada comparable systemwide RevPAR); Airbnb shareholder letters. "
         "Different measures (RevPAR vs. volume) - compare direction, not level.", fontsize=6.5, color=MUTED)
fig.tight_layout(rect=(0, 0.04, 1, 1))
OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, facecolor=SURFACE)
print("wrote", OUT)
