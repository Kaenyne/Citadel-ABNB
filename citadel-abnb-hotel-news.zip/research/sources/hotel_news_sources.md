# Sources — hotel news / events vs. ABNB (added Sept 6, 2026)

Append these rows to `research/sources/README.md`.

| Date | Source | Used for |
|---|---|---|
| 2026-08 | CoStar, U.S. Hotel Forecast Assumptions – August 2026 — https://www.costar.com/products/str-benchmark/resources/data-insights-blog/us-hotel-forecast-assumptions-august-2026 | FY26 RevPAR +4.4%, ADR +3.1%, supply +0.4%; 2027 prelim; inbound +0.2% YTD |
| 2026-09-01 | STR via Hotel News Resource, U.S. Hotel Outlook for 2027 — https://www.hotelnewsresource.com/article142712.html | 2027 supply +0.6%, ADR below inflation, June-27 RevPAR −0.8% |
| 2026-08-10 | CoStar, "2026 is the year of hotel rate growth" — https://www.costar.com/article/1232755824/2026-is-the-year-of-hotel-rate-growth-and-the-world-cup-is-only-part-of-the-story | Rate-led growth; supply <1% |
| 2026-07-24 | CoStar, World Cup concludes with record host-market rates — https://www.costar.com/article/1261496447/world-cup-concludes-with-record-host-market-hotel-rates | NYC ADR $610; Atlanta −6.4%; Seattle occ |
| 2026-07-06 | Hotel Dive, host cities exceed RevPAR forecast — https://www.hoteldive.com/news/hotels-world-cup-host-cities-exceed-revpar-forecast/824474/ | Miami +51.6%, SF +40.7%, Dallas +27.2% |
| 2026-05-12 | Fortune / AHLA survey — https://fortune.com/2026/05/12/us-hotels-world-cup-bookings-falling-short-expectations-report/ | ~80% of host-city hotels below forecast pre-event |
| 2026-08-03 | Marriott Q2 2026 release — https://marriott.gcs-web.com/news-releases/news-release-details/marriott-international-reports-second-quarter-2026-results | US&C +5.0%; occ 71.6%; ADR +3.5%; FY 3–3.5%; ME −43% |
| 2026-07-28 | Hilton Q2 2026 release — https://ir.hilton.com/~/media/Files/H/Hilton-Worldwide-IR-V3/quarterly-results/2026/q2-2026-earnings-release-hlt.pdf | US +5.4%; FY 3–3.5%; Q4 midterms/calendar |
| 2026-07-30 | Hyatt Q2 2026 release — https://newsroom.hyatt.com/Q2-2026-Earnings-Release | FY 3.5–4.5% |
| 2026-08-21 | CoStar, execs on events/headwinds — https://www.costar.com/article/1588935570/hotel-executives-champion-events-impact-on-2026-performance-while-monitoring-global-headwinds | World Cup ~45 bps (MAR); midterms; Pebblebrook July +7–8% |
| 2026-08-06 | Airbnb Q2 2026 results + shareholder letter — https://news.airbnb.com/airbnb-q2-2026-financial-results/ ; https://s26.q4cdn.com/656283129/files/doc_financials/2026/q2/Airbnb-Q2-2026-Shareholder-Letter.pdf | Rev +17%; nights +10%; ADR $184 (+5%, NA +7%); hotels 3x; 150k host-city homes |
| 2026-08-06 | PhocusWire, Airbnb continues hotel push — https://www.phocuswire.com/news/finance/airbnb-q2-2026-earnings | Chesky "stepping on the gas"; Lark 75+; 35% rebook homes |
| 2026-08 | TIKR, Airbnb jumped 17% — https://www.tikr.com/blog/airbnb-jumped-17-today-heres-where-the-stock-is-headed-in-2026 | Post-Q2 stock ~$178, 4-yr high |
| 2026-05-07 | Airbnb Q1 2026 results — https://news.airbnb.com/airbnb-q1-2026-financial-results/ | Nights +9%; GBV +19%; rev +18%; 55% hotel→home |
| 2026-02-12 | Airbnb Q4 2025 results — https://news.airbnb.com/airbnb-q4-2025-financial-results/ | Nights +10%; GBV +16%; rev +12%; hotels pilot |
| 2025-11-06 | PhocusWire, Airbnb Q3 2025 — https://www.phocuswire.com/airbnb-q3-2025-earnings | Nights +9%; GBV +14%; rev +10%; LA/NYC/Madrid pilot |
| 2025-08-06 | Reuters via Yahoo, Airbnb Q2 2025 — https://finance.yahoo.com/news/airbnb-forecasts-quarterly-revenue-above-200754622.html | Nights +7%; H2 caution; −6% AH |
| 2026-05-06 | Hotel Dive, Marriott Q1 2026 — https://www.hoteldive.com/news/marriott-q1-2026-earnings/819442/ | US&C +4.0%; guide 2–3% |
| 2026-02-10 | Hotel Dive, Marriott Q4 2025 — https://www.hoteldive.com/news/marriott-earnings-q4-2025/811812/ | US&C −0.1%; shutdown |
| 2025-11-04 | Hotel Dive, Marriott Q3 2025 — https://www.hoteldive.com/news/marriott-q3-2025-earnings-portfolio-growth/804614/ | US&C −0.4% |
| 2025-08-13 | Hotel Dive, CEOs on Q2 RevPAR declines — https://www.hoteldive.com/news/hotel-ceo-insights-q2-revpar-declines/757538/ | MAR flat; HLT US −1.5%; WH −4%; CHH −2.9% |
| 2025-05-19 | Hotel Dive, Q1 2025 tariffs/downgrades — https://www.hoteldive.com/news/hotel-earnings-tariffs-revpar-development/748396/ | Guide cuts; inbound drop |
| 2025-05-08 | Asian Hospitality, Marriott Q1 2025 — https://www.asianhospitality.com/marriott-revpar-q1-2025-usa/ | US&C +3.3%; FY 1.5–3.5% |
| 2025-11-14 | Hotel Dive, FY25 RevPAR decline — https://www.hoteldive.com/news/hotel-revpar-decline-2025-costar-tourism-economics-forecast/805528/ | RevPAR −0.4%; ADR +0.8%; occ 62.3% |
| 2026-03-06 | CoStar, 2025 disruptions — https://www.costar.com/article/263194719/execs-describe-how-disruptions-hit-hotels-unevenly-throughout-2025 | MAR govt RevPAR −30%+ in shutdown |
| 2026-01-09 | Hotel Dive, shutdown losses — https://www.hoteldive.com/news/government-shutdown-financial-loss-travel-tourism/809210/ | $6.1B travel; ~$1.18B hotels by day 38 |
| 2026-08-10 | Spectrum News, fall shutdown warning — https://spectrumlocalnews.com/us/snplus/transportation/2026/08/10/travel-industry-disruptions-government-shutdown- | Sept 30 deadline; $1B/week |
| 2024-09-01 | Skift, Banned in NYC one year later — https://skift.com/2024/09/01/banned-in-nyc-airbnb-1-year-later/ | Listings −83%; NYC RevPAR +10.1% |
| 2026 | amNY, NYC STR registration data 2026 — https://www.amny.com/housing/new-short-term-rental-data-2026/ (not fetched; verify bill status) | LL18 loosening bills |
| 2024-09 | Skift, hotel strikes — https://skift.com/2024/09/23/u-s-hotel-strikes-escalate-as-40000-workers-face-contract-expirations/ | 40k workers |
| 2026-09-02 | Bisnow, Chicago contracts expire — https://www.bisnow.com/news/chicago/hotel/union-contracts-expire-46-chicago-hotels-strike-looming | 46 hotels; 7k workers |
| 2025-11 | CBS News, Sonder shutdown — https://www.cbsnews.com/news/sonder-marriott-bonvoy-partnership-guests-24-hours-vacate-rooms/ | Nov 9–10, 2025; Chapter 7 |
| 2026 | AirROI, Airbnb vs hotel all-in pricing 2026 — https://www.airroi.com/blog/airbnb-vs-hotel-all-in-pricing-2026 | 27/28 hotels cheaper solo; 19/28 ABNB wins vs 2 rooms |
| 2026 | AirROI, Airbnb hotels expansion host impact — https://www.airroi.com/blog/airbnb-hotels-expansion-str-host-impact-2026 | Urban 1-BR overlap $127–219 |
| 2023 | The Science of Hitting, Airbnb ADRs — https://thescienceofhitting.com/p/airbnb-adrs-and-affordability | ADR $122→$168; MAR NA +13% |
| 2026-05-20 | CNBC (403 on fetch; via Rental Scale-Up) — https://www.rentalscaleup.com/airbnbs-hotel-strategy-in-2026-what-the-q1-earnings-call-hiring-data-and-hoteltonight-tell-us/ | Hotels + cars launch |
