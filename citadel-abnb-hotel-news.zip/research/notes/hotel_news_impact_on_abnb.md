# Hotel news & events → what they did to Airbnb, and what's coming

*Author: Jessie (w/ Claude) · Sept 6, 2026 · Status: draft for prelim memo (due Oct 2)*
*Companion files: `data/processed/hotel_events_timeline.csv`, `hotel_catalyst_calendar.csv`, `hotel_vs_abnb_quarterly_kpis.csv`; `analysis/src/hotel_abnb_event_study.py` (run locally); `docs/figures/hotel_vs_abnb_growth.png`*

## TL;DR

- **Hotel news moves ABNB through three channels, not one.** (1) *Shared travel beta* — macro shocks (tariffs, shutdowns, inbound drops) hit both; (2) *Relative price* — when hotel ADR runs hot, ABNB's whole-home value gap widens for families/long stays; (3) *Supply/regulation* — hotel-lobby-driven STR bans (NYC LL18) are the only hotel "event" that has clearly *taken* share from ABNB.
- **2025 was a hotel down-year (US RevPAR −0.4%, first decline since 2009 ex-2020) and ABNB grew nights 7–10% every quarter.** Hotels' exposure to government + business-transient travel is exposure ABNB doesn't have. The 43-day shutdown quarter (Q4'25) was ABNB's best growth quarter of the year while Marriott US&C RevPAR went negative.
- **2026 flipped hotels to ADR-led growth (MAR US&C +5.0%, HLT US +5.4% in Q2) with occupancy flat** — hotels are pricing, not filling. STR/CoStar forecasts FY26 RevPAR +4.4% on supply growth of just +0.4%. That's a tailwind for ABNB's relative affordability, and ABNB's own ADR (+5%, NA +7%) is *outrunning* hotel ADR.
- **The competitive relationship inverted in 2026.** Airbnb now *distributes* hotels (thousands of boutique/independents across 20+ cities; hotel nights growing ~3x homes; 35% of first-time hotel bookers rebook a home). Marriott's attempt to run an STR-like product (Sonder) collapsed in Nov 2025.
- **Nearest hotel catalysts:** Sept 30 funding deadline/shutdown risk (hotel-negative, ABNB relatively positive); Hilton Q3 ~Oct 21–23 and Marriott Q3 ~Nov 3–5 (dates not yet announced) as read-throughs into ABNB Q3 (~Nov 5–6); Nov 3 midterms (both chains flagged a small Q4 hit); STR's 2027 outlook already calls for June 2027 RevPAR −0.8% on World Cup comps — ABNB laps the same comp.
- **Pitch implication:** hotel data supports the *long* side on relative growth and pricing power; the *short* side needs the World Cup comp + hotels-channel margin dilution (hotel take-rate lower, EBITDA margin guided "slightly down" in Q3) — not a hotel-share-loss argument, which the data doesn't support outside NYC.

---

## 1. How hotel events transmit to ABNB (framework)

| Channel | Mechanism | Sign for ABNB | Historical evidence |
|---|---|---|---|
| Shared travel beta | Macro/policy shocks hit total trips | Same sign as hotels, smaller magnitude | Apr-2025 tariff scare: MAR/HLT/H all cut FY guides; ABNB Q2'25 nights +7% (slowest of 2025) and stock −6% AH on H2 caution |
| Business/government mix | Hotels carry govt + business-transient; ABNB is leisure/long-stay | ABNB *relatively* better when govt/BT weak | Q4'25 shutdown: MAR govt RevPAR −30%+, US&C RevPAR −0.1%; ABNB nights +10%, GBV +16% |
| Relative price | Hotel ADR ↑ (supply-starved) → ABNB whole-home wins for 2+ rooms / longer stays | Positive for volume; mixed for ABNB ADR | 2021–23: ABNB ADR +38% vs Marriott NA +~13% → "Airbnbust" affordability backlash; 2026: hotels ADR-led, ABNB wins 19/28 markets vs 2 hotel rooms at 3 nights (AirROI) |
| Event demand | Mega-events spike hotel ADR, overflow to STRs, add durable STR supply | Positive, sticky | World Cup 2026: host-city hotel RevPAR >+20% but occupancy flat/down (Seattle −6.9 pts); ABNB added 150k+ first-time host-city homes |
| Regulation (hotel-lobby driven) | STR bans remove ABNB supply, hand demand to hotels | Negative, market-specific | NYC LL18: short-stay listings −83%; NYC hotel RevPAR +10.1% H1'24 vs +2.5% peers |
| Labor | Strikes disrupt full-service hotels | Small, local, short-lived | Sept 2024 (40k workers; SF 93 days); Chicago 46 hotels now without contract |
| Hotel-run STR products | Bonvoy Homes & Villas, Sonder | Neutral → positive (they keep failing) | Sonder Chapter 7 Nov 2025 after Bonvoy integration "sharp decline in revenue" |
| ABNB-run hotel product | Hotels on Airbnb (2025 pilot → 2026 rollout) | Positive volume, margin-dilutive | Hotel nights ~3x homes growth; single-digit % of nights; Q3 EBITDA margin guided slightly down |

## 2. Timeline of hotel events and ABNB response (full table in CSV)

**2019–2023 — hotels vs. Airbnb as substitutes**
- Apr 2019: Marriott Homes & Villas — loyalty-tied whole-home product. Never scaled against ABNB.
- 2020: COVID — hotels lose ~half of RevPAR; ABNB's whole-home/drive-to mix rebounds first → Dec 2020 IPO.
- 2021–Q1'23: ABNB ADR ~$122 → ~$168 (+38%) vs. Marriott NA ADR +~13%. Pricing above hotels triggered the 2023 affordability backlash (fees, cleaning) and Airbnb's total-price display.
- **Sept 2023: NYC Local Law 18.** The clearest hotel-lobby win: NYC short-stay ABNB listings 21.9k → 3.7k (−83%) in a year; NYC hotel RevPAR +10.1% in H1'24 (best of top-25 markets). Airbnb never disclosed NYC revenue hit.

**2024–2025 — both sectors soften, hotels more**
- Sept 2024: UNITE HERE strikes (Hilton/Hyatt/Marriott; 40k workers with expiring contracts). Local, temporary; no disclosed ABNB effect.
- May 2025: Q1 prints — tariffs, "sharp and widespread drop in inbound," government travel freeze. MAR cuts FY25 to 1.5–3.5%. ABNB Q1'25 nights +8%.
- Aug 2025: Q2 prints — MAR US&C flat, HLT US −1.5%, WH −4%, CHH −2.9%. ABNB nights +7%, flags Q4 moderation; stock −6% AH. **Read: shared macro beta, not substitution.**
- **Oct 1–Nov 12, 2025: 43-day shutdown.** ~$1.18B hotel losses by day 38; MAR govt RevPAR −30%+; MAR US&C Q4 −0.1%. ABNB Q4'25 = best growth quarter of 2025 (nights +10%, GBV +16%).
- Nov 10, 2025: **Sonder collapses** (Chapter 7) after Marriott Bonvoy integration failed — hotels can't run STR-like inventory.
- Nov 14, 2025: CoStar/TE finalize FY25 US RevPAR **−0.4%**, ADR +0.8%, occ 62.3%. ABNB FY25 revenue ~+12%.

**2026 — hotels recover on rate; Airbnb becomes a hotel channel**
- Feb 2026: ABNB Q4 — hotels pilot (LA/NYC/Madrid) "scaling"; 2026 revenue "at least low double digits." MAR Q4 US&C −0.1%.
- May 2026: Q1 — MAR US&C +4.0%, FY guide raised to 2–3%; broad-based US RevPAR growth. ABNB Q1 nights +9%, GBV +19%, rev +18%. May 20: Airbnb launches hotels + car rentals in-app.
- **Jun 11–Jul 19: World Cup.** AHLA pre-event survey: ~80% of host-city hotels tracking below forecast. Actual: an *ADR* event — host cities RevPAR "well above 20%" (Miami +51.6%, SF +40.7%, Dallas +27.2%), NYC final-night ADR $610 record; but Atlanta RevPAR −6.4%, Seattle occupancy −6.9 pts in-tournament. National June-27 week: ADR +9.2%, occupancy +0.4%. ABNB: 150k+ first-time host-city listings, "millions" of arrivals.
- Jul 28 / Aug 3: HLT US +5.4% (FY 3–3.5%, flags Q4 midterms/calendar); MAR US&C +5.0% (FY raised to 3–3.5%; occupancy 71.6%, −0.1 pt; ADR +3.5%; World Cup ~45 bps global). **Occupancy flat, ADR up = pricing power from a 0.4% supply pipeline, not demand.**
- Aug 6: ABNB Q2 — rev +17%, nights +10% (accelerating), ADR $184 (+5%; NA +7%), hotels "significantly better than expected," stock ~+17% to ~$178 (4-yr high).
- Aug 10 / Sep 1: CoStar — "2026 is the year of hotel rate growth"; FY26 RevPAR +4.4%, ADR +3.1%, supply +0.4%. **2027: supply +0.6% (lowest construction in 12 yrs), ADR below inflation, June 2027 RevPAR −0.8% on World Cup comps.**

## 3. What the data says (the punchlines)

1. **ABNB growth is uncorrelated with hotel RevPAR at the fundamental level over 2025–26** — hotels swung from +3.3% → −0.4% → +5.0% (MAR US&C) while ABNB nights stayed in a 7–10% band. Chart: `docs/figures/hotel_vs_abnb_growth.png`. Stock-level correlation likely remains high (travel beta) — run `hotel_abnb_event_study.py` locally to quantify (yfinance is blocked in the cloud session).
2. **Hotel weakness ≠ ABNB share gain when the cause is demand; hotel weakness from *mix* (govt/BT) = ABNB relative gain.** Q2'25 vs Q4'25 is the clean contrast.
3. **Hotel strength in 2026 is rate-led with occupancy flat** — that's the best possible hotel backdrop for ABNB: hotels raising the price umbrella without absorbing incremental heads-in-beds.
4. **Airbnb's all-in price problem is real for short solo/couple stays** (hotels cheaper in 27/28 markets at 3 nights; ABNB checkout total ~56% above listed nightly rate) **and irrelevant for the segments ABNB is actually growing** (4+ BR homes fastest-growing; ABNB wins 22/28 markets vs 2 hotel rooms at 7 nights). Airbnb's hotel channel is explicitly aimed at the short-stay/regulated-city gap it was losing.
5. **The only hotel-driven event that demonstrably hurt ABNB was regulatory (NYC LL18)** — hotel-lobby policy, not hotel operations, is the risk to monitor.

## 4. Upcoming hotel news / catalysts (full calendar in CSV)

| When | What | Hotel read | ABNB read |
|---|---|---|---|
| **Now** | Chicago UNITE HERE Local 1: 46 hotels / 7k workers without contract since Aug 31; strike "at any time" | − Hyatt/Marriott Chicago | small local + |
| **Sept 30** | Federal funding deadline; shutdown risk Oct 1 (industry warning Aug 10) | − govt/BT RevPAR, D.C./select-service | relative + (Q4'25 precedent) |
| Oct 1 | FY27 GSA per diems | caps govt ADR | none |
| **~Oct 21–23** (est.) | Hilton Q3 — first post-World Cup big-chain print | deceleration vs +5.4% | 2-week lead read on ABNB US Q3 |
| ~Oct 29–30 (est.) | Hyatt Q3 | luxury/leisure check | high-end homes read |
| **Nov 3** | Midterm elections | small − (in guides) | small − |
| **~Nov 3–5** (est.) | Marriott Q3 | is growth still ADR-only? | value-gap read |
| **~Nov 5–6** (est.) | **Airbnb Q3** | — | nights vs +10%, ADR vs $184, hotel-nights share, new markets |
| Nov | CoStar/TE forecast update | FY26/27 RevPAR revisions | pricing backdrop |
| Nov–Dec (unverified) | NYC bills loosening LL18 for owner-occupied 1–2 family homes | − NYC hotels | upside optionality |
| Late Jan 2027 | ALIS — 2027 forecasts, supply | supply +0.6% | pricing umbrella persists |
| Early Feb 2027 | FY26 prints + first 2027 guides | slower 2027 | ABNB FY27 guide vs World Cup comp |
| Feb 14, 2027 | Super Bowl LXI, LA (SoFi) | LA rate event | LA = STR-restricted, ABNB hotels-pilot market |
| Jun–Jul 2027 | World Cup comps (STR: June RevPAR −0.8%) | − host cities | ABNB laps "millions" of arrivals — Q2'27 guide risk |
| Ongoing | Inbound weakness (+0.2% YTD incl. World Cup), Middle East, ABNB hotel rollout | gateway cities −, EMEA − | expansion markets offset; hotels channel + |

*Earnings dates marked (est.) are inferred from 2025 timing; none of HLT/MAR/H/ABNB has announced Q3'26 dates as of Sept 6. Update the calendar when they do.*

## 5. How to use this in the pitch

- **Long case:** "Airbnb decoupled from the hotel cycle in 2025 and is now monetizing it in 2026." Evidence: nights 7–10% through a hotel RevPAR down-year; ADR growth above hotel ADR; hotels channel growing 3x; supply-starved hotels (+0.4–0.6% supply) keep the price umbrella high through 2027.
- **Short case (from hotel data):** (a) June–July 2027 comp — hotels are already guiding for it, ABNB isn't; (b) hotels channel dilutes take-rate/margin (Q3 EBITDA margin guided down); (c) hotel all-in price wins 27/28 markets for short stays and Airbnb's "price-match + 15% credit" on hotels is a margin subsidy; (d) regulatory contagion (LL18-style) is the tail risk.
- **Model hooks for Krishang/Theo:** use hotel ADR forecast (+3.1% FY26, +1.6% FY27 incl. World Cup drag) as an anchor for ABNB NA ADR growth; add a June-2027 nights comp haircut; treat hotel nights as a separate line with lower take-rate.
- **Alt-data tie-in (Jessie):** Inside Airbnb accommodates/bedrooms data can test the "ABNB wins at 2+ rooms" claim directly; the 150k new host-city listings should show up in review velocity for Miami/NYC/SF/Dallas Jun–Jul 2026 and in retention by Q4.

## Sources (also logged in `research/sources/hotel_news_sources.md`)

CoStar/STR forecast Aug 2026 · STR 2027 outlook (Sep 1, 2026) · CoStar World Cup wrap (Jul 24, 2026) · Hotel Dive World Cup host cities (Jul 6, 2026) · Fortune/AHLA survey (May 12, 2026) · Marriott Q2'26 release (Aug 3, 2026) · Hilton Q2'26 release (Jul 28, 2026) · CoStar exec commentary (Aug 21, 2026) · Airbnb Q2'26 letter + PhocusWire (Aug 6, 2026) · Airbnb Q1'26, Q4'25, Q3'25 results · Hotel Dive Q2'25 (Aug 13, 2025), Q1'25 (May 19, 2025), Q3'25 MAR (Nov 4, 2025), Q4'25 MAR (Feb 10, 2026), Q1'26 MAR (May 6, 2026) · Hotel Dive FY25 forecast (Nov 14, 2025) · Hotel Dive shutdown losses (Jan 9, 2026) · CoStar 2025 disruptions (Mar 6, 2026) · Skift NYC LL18 one year (Sep 1, 2024) · Skift strikes (Sep 2024) · Bisnow Chicago (Sep 2, 2026) · CBS Sonder (Nov 2025) · AirROI all-in pricing 2026 · AirROI hotels-vs-STR 2026 · Science of Hitting ADR history · Spectrum shutdown warning (Aug 10, 2026) · TIKR (Aug 2026)
