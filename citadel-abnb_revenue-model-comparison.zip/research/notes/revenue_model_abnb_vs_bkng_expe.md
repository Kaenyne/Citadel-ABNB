# Revenue model: Airbnb vs Booking Holdings vs Expedia Group

Author: Jessie (drafted with Claude), 2026-09-06
Data: `data/processed/revenue_model_comparison_fy2025.csv` (every figure carries its source URL)

## Bottom line

- Same *category*, not the same *model*. All three are asset-light two-sided marketplaces that book revenue **net** (as agent) as a % of gross bookings, recognized when the stay starts. That is where the similarity ends.
- Airbnb has **one** revenue stream (service fees on stays, plus small experiences/services fees), collects 100% of guest cash at booking, and charges a **visible guest-facing fee**. Booking and Expedia have **three to four** streams (merchant, agency, advertising, and for Expedia a large B2B wholesale segment), a mix of merchant and agency payment models, and fees that are mostly **invisible to the traveler** (embedded in the rate / paid by the supplier).
- FY2025 take rate (revenue / gross bookings): **BKNG 14.5%** > **ABNB 13.4%** > **EXPE 12.3%**. Booking's is rising (14.3% in FY2024) as it shifts to merchant; Airbnb's is slipping (Q4'25 13.6% vs 14.1% Q4'24); Expedia's is structurally lowest because B2B and air carry lower margins.

## 1. How each one actually earns a dollar

| | Airbnb | Booking Holdings | Expedia Group |
|---|---|---|---|
| Primary fee | Service fee on each stay. Split fee: host 3% (4% BR/MX) + guest 14.1–16.5% of subtotal. Host-only fee: 15.5% (16% BR/MX), mandatory for hotels, PMS-connected hosts and some countries. Experiences ~20%, Services ~15%. | Commission paid by the property on completed stays (rate set per country / property type; third-party guides put the typical rate near 15%). Under merchant model, also "transaction net revenues" (amount charged to traveler less amount owed to supplier), payment-facilitation revenue (card rebates, processing fees) and ancillary fees. | Merchant ("Expedia Collect"): Expedia is merchant of record, revenue = customer payment less negotiated net rate. Agency ("Hotel Collect"): commission from the hotel. Plus B2B (white-label / API supply to airlines, banks, offline agents) and advertising (trivago, EG media). |
| Who pays the fee | Both sides today; migrating toward host-only (fee invisible to guest) | Supplier (property); guest sees no separate fee | Supplier / embedded in price; guest sees no separate fee |
| Cash flow at booking | Airbnb collects the full stay amount at booking, holds it until check-in, pays host ~1 business day after check-in | Merchant bookings: collects at booking (70% of GB). Agency: never touches the cash | Merchant bookings: collects at booking (60% of GB). Agency: never touches the cash |
| Revenue recognition | Net; at check-in | Net; at check-in (accommodation) | Net; at stay (agency hotel), at booking (air) |
| Float / interest income | FY25 interest income $705mm on $6,959mm funds held for customers; = 5.8% of revenue, ~28% of net income | Earns on merchant float too, but not broken out the same way | Same, smaller |

Sources: Airbnb fee schedule ([Airbnb Help 1857](https://www.airbnb.com/help/article/1857)); host-only fee migration timeline ([Rental Scale-Up](https://www.rentalscaleup.com/airbnb-host-only-fee/)); Airbnb cash mechanics and 61% non-US revenue ([ABNB FY2025 10-K](https://www.sec.gov/Archives/edgar/data/1559720/000155972026000004/abnb-20251231.htm)); Airbnb interest income, S&M, unearned fees ([ABNB Q4'25 shareholder letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter.pdf)); Booking revenue definitions ([BKNG FY2025 10-K](https://www.sec.gov/Archives/edgar/data/1075531/000107553126000009/bkng-20251231.htm)); Booking commission mechanics ([Booking.com Partner Help](https://partner.booking.com/en-us/help/commission-invoices-tax/commission/understanding-our-commission); ~15% typical per [Lodgify](https://www.lodgify.com/guides/booking/fees/)); Expedia model definitions ([EXPE FY2025 10-K summary](https://www.stocktitan.net/sec-filings/EXPE/10-k-expedia-group-inc-files-annual-report-38a15f53cacb.html)).

## 2. FY2025 scale and mix

| FY2025 | ABNB | BKNG | EXPE |
|---|---|---|---|
| Revenue | $12.2B | $26.9B | $14.7B |
| Gross bookings | $91.3B (GBV) | $186.1B | $119.6B |
| Take rate | 13.4% | 14.5% (FY24: 14.3%) | 12.3% (Q4: 13.1%) |
| Merchant % of gross bookings | 100% | 69.9% (FY24: 62.9%) | 59.9% |
| Revenue mix | ~100% service fees | Merchant 66% / Agency 30% / Ads & other 4% | Merchant 70% / Agency 22% / Ads & other 8% |
| Segment mix | Single segment | Single reportable business (Booking.com dominant; also Priceline, Agoda, KAYAK, OpenTable) | B2C 64% / B2B 33% / trivago 3% |
| Lodging % of gross bookings | ~100% | not disclosed (flights GB $16.8B = 9%) | 73% |
| Units | 533.0mm nights & seats | 1,235mm room nights, 88mm car days, 68mm air tickets | 415.4mm room nights |
| Marketing % of revenue | 21% | 30% | n/a here |
| Net income / Adj. EBITDA | $2.5B / $4.3B (35% margin) | $5.4B / $9.9B | $1.3B / $3.5B |

Sources: [ABNB Q4'25 shareholder letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter.pdf); [BKNG Q4'25 earnings release](https://s201.q4cdn.com/865305287/files/doc_financials/2025/q4/Q4-25-BKNG-Earnings-Release.pdf); [BKNG FY25 marketing $8.2B, flights GB $16.8B — PhocusWire](https://www.phocuswire.com/booking-holdings-q4-full-year-2025-earnings); [EXPE Q4/FY25 release](https://ir.expediagroup.com/news-and-events/news/news-details/2026/Expedia-Group-Reports-Fourth-Quarter-and-Full-Year-2025-Results/default.aspx) and [BusinessWire tables](https://www.businesswire.com/news/home/20260212146454/en/Expedia-Group-Reports-Fourth-Quarter-and-Full-Year-2025-Results); Expedia 70/22/8 revenue-by-model from the [FY2025 10-K](https://www.stocktitan.net/sec-filings/EXPE/10-k-expedia-group-inc-files-annual-report-38a15f53cacb.html). Take rates and mix percentages are computed from the reported figures.

## 3. The five structural differences that matter for the pitch

1. **Fee visibility.** Airbnb is the only one whose core fee is a line item the guest sees (14.1–16.5%). That makes its take rate exposed to total-price-display rules, guest fee fatigue and hotel "book direct" comparisons in a way Booking/Expedia's supplier-paid commissions are not. The Oct–Dec 2025 migration of PMS and non-PMS hosts to a single 15.5% host-only fee is Airbnb moving toward the OTA convention — the fee disappears from the guest's checkout and the host is expected to reprice (Rental Scale-Up estimates hosts need ~+14.8% on rate to keep payout flat).
2. **Take-rate levers.** Booking's take rate is climbing because merchant mix went 63% → 70% of GB in one year and merchant bookings carry payments revenue on top of commission. Airbnb is already 100% merchant, so it has no equivalent mix tailwind; its levers are fee rate, Services/Experiences (higher %, small base) and FX. Expedia's is diluted by B2B (growing 24% but lower margin) and air.
3. **Diversification.** Airbnb ≈ one product, one fee. Booking has flights (tickets +39% YoY), cars, KAYAK/OpenTable ads. Expedia has a third of revenue in B2B wholesale plus advertising. A lodging-demand shock hits Airbnb's P&L one-for-one; the OTAs have partial offsets.
4. **Float is a real earnings line for Airbnb.** $705mm of FY25 interest income ≈ 28% of net income, and it fell from $818mm in FY24 as rates came down. Any model should treat this as rate-sensitive, not operating income. Booking/Expedia have float on merchant bookings only.
5. **Supplier bargaining.** Booking/Expedia negotiate commission and net rates with professional hoteliers (and hotels can retaliate with loyalty/direct pricing — see `hotel_loyalty_stickiness_vs_abnb.md`). Airbnb's supply is millions of individual hosts with little pricing power vs the platform, which is why it can push a uniform 15.5% globally.

## 4. Modeling notes for Krishang / Theo

- Model ABNB revenue as GBV × take rate, with take rate driven by (a) host-only fee mix, (b) FX (61% of revenue non-US), (c) Services/Experiences mix, and (d) booking-to-stay timing. Airbnb itself attributes the Q4'25 drop to FX and timing, not fee changes.
- Keep interest income below the operating line and tie it to funds held for customers ($6.96B) × a short-rate assumption.
- For comps: BKNG take rate benefits from payments revenue that ABNB already has embedded — so ABNB's 13.4% vs BKNG's 14.5% is roughly like-for-like on a merchant basis, while EXPE's 12.3% is not (B2B drag).
- If the team wants a "peer take-rate" sensitivity, ±50bp on ABNB's 13.4% is ≈ ±$460mm of FY25 revenue (on $91.3B GBV).

## Open items

- Pull FY2024 GBV for ABNB and FY2024 gross bookings for EXPE from the prior-year releases to complete the take-rate history (2019–2025) as a time series in `data/processed/`.
- Booking.com's actual blended commission rate is not disclosed; treat ~15% as an industry estimate, not a company figure.
