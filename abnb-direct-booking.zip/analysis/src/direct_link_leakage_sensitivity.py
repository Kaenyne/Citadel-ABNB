"""
Direct-booking-link leakage sensitivity for ABNB.

Question: if Airbnb rolls out the "share your link, get a lower fee" pilot
(Skift, 29 Aug 2026: 6-10% host fee on host-sourced bookings vs 15.5% standard),
how much revenue / EBITDA is at risk?

Two flows:
  1. CANNIBALIZED GBV  - bookings that would have come through Airbnb at 15.5%
                         anyway, now booked at the discounted fee. Pure take-rate loss.
  2. INCREMENTAL GBV   - bookings that were previously off-platform "true direct"
                         (owner websites, repeat guests) and move ONTO Airbnb at the
                         discounted fee. Pure revenue gain.

Revenue effect on a booking is scaled by (fee / 15.5%) applied to Airbnb's
implied take rate, because the 15.5% headline fee applies to the host subtotal
while implied take rate = revenue / GBV (GBV includes taxes, cleaning fees etc.).

Baseline inputs (FY2025, Airbnb Q4-2025 shareholder letter):
  GBV $91.3B, revenue $12.2B, adj. EBITDA $4.3B  -> implied take rate 13.4%

Outputs:
  data/processed/direct_link_leakage_sensitivity.csv   (long-format grid)
  docs/direct_link_leakage_sensitivity.png             (chart)
"""
from __future__ import annotations

import itertools
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT_CSV = ROOT / "data" / "processed" / "direct_link_leakage_sensitivity.csv"
OUT_PNG = ROOT / "docs" / "direct_link_leakage_sensitivity.png"

# ---- Baseline (FY2025) ------------------------------------------------------
GBV_B = 91.3            # $B, Airbnb Q4-2025 shareholder letter
REV_B = 12.2            # $B, same
EBITDA_B = 4.3          # $B adj. EBITDA, same
TAKE = REV_B / GBV_B    # implied take rate ~13.4%
STD_FEE = 0.155         # standard single host service fee (Airbnb help centre / Skift)
FLOW_THROUGH = 0.90     # share of lost/gained revenue that hits EBITDA (assumption:
                        # payment processing is the main variable cost on a fee change)

# ---- Grid -------------------------------------------------------------------
link_fees = [0.06, 0.08, 0.10]                      # pilot tiers reported: 6% / 10%; 8% midpoint
gbv_shares = [0.01, 0.02, 0.03, 0.05, 0.075, 0.10, 0.15, 0.20]  # share of GBV booked via links
cannib = [0.0, 0.25, 0.50, 0.70, 0.85, 1.0]         # share of link GBV that is cannibalized

rows = []
for fee, share, c in itertools.product(link_fees, gbv_shares, cannib):
    link_gbv = GBV_B * share
    cann_gbv = link_gbv * c
    incr_gbv = link_gbv * (1 - c)
    # revenue per $ of GBV at the standard fee = TAKE; at the link fee = TAKE * fee/STD_FEE
    rev_loss = cann_gbv * TAKE * (1 - fee / STD_FEE)
    rev_gain = incr_gbv * TAKE * (fee / STD_FEE)
    net = rev_gain - rev_loss
    rows.append({
        "link_fee": fee,
        "gbv_share_via_links": share,
        "cannibalized_share": c,
        "link_gbv_B": round(link_gbv, 3),
        "rev_loss_B": round(rev_loss, 4),
        "rev_gain_B": round(rev_gain, 4),
        "net_rev_B": round(net, 4),
        "net_rev_pct_of_FY25_rev": round(net / REV_B, 4),
        "net_ebitda_B": round(net * FLOW_THROUGH, 4),
        "net_ebitda_pct_of_FY25_ebitda": round(net * FLOW_THROUGH / EBITDA_B, 4),
    })

df = pd.DataFrame(rows)
OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
df.to_csv(OUT_CSV, index=False)

# Break-even cannibalization: net = 0  ->  c* = fee / STD_FEE  (independent of share)
for fee in link_fees:
    print(f"fee {fee:.0%}: break-even cannibalized share = {fee/STD_FEE:.1%} "
          f"(below this the pilot is revenue-accretive)")

# ---- Chart: net revenue impact vs share of GBV via links, 8% fee ---------------
sub = df[df.link_fee == 0.08]
fig, ax = plt.subplots(figsize=(8, 4.8), dpi=150)
palette = {1.0: "#2a78d6", 0.70: "#eb6834", 0.25: "#1baf7a"}   # dataviz reference slots 1-3
labels = {1.0: "100% cannibalized", 0.70: "70% cannibalized", 0.25: "25% cannibalized"}
for c, color in palette.items():
    s = sub[sub.cannibalized_share == c]
    ax.plot(s.gbv_share_via_links * 100, s.net_rev_pct_of_FY25_rev * 100,
            color=color, lw=2, marker="o", ms=5, label=labels[c])
    x, y = s.gbv_share_via_links.iloc[-1] * 100, s.net_rev_pct_of_FY25_rev.iloc[-1] * 100
    ax.annotate(labels[c], (x, y), xytext=(6, 0), textcoords="offset points",
                va="center", fontsize=8, color="#52514e")
ax.axhline(0, color="#c3c2b7", lw=1)
ax.set_xlabel("Share of Airbnb GBV booked through host direct links (%)")
ax.set_ylabel("Net revenue impact (% of FY2025 revenue)")
ax.set_title("ABNB: direct-link pilot is a take-rate question, not a volume question\n"
             r"(8% link fee vs 15.5% standard; FY2025 GBV \$91.3B, revenue \$12.2B)", fontsize=10)
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", color="#eeeeea", lw=0.8)
ax.set_xlim(0, 24)
ax.legend(frameon=False, fontsize=8, loc="lower left")
fig.tight_layout()
OUT_PNG.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT_PNG)
print("wrote", OUT_CSV, OUT_PNG)
