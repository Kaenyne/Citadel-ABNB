# Direct booking links: will they actually hurt Airbnb?

*Research note — Sept 6, 2026. Author: Jessie (alt-data workstream). Status: draft for team review.*

## TL;DR

- **Two different "direct booking" stories are getting conflated.** (1) The *Book Direct* movement — hosts pushing guests to their own websites to dodge Airbnb entirely. (2) Airbnb's own **direct-booking-link pilot** (reported by [Skift, Aug 29 2026](https://skift.com/2026/08/29/airbnb-is-testing-lower-fees-for-hosts-who-bring-their-own-guests/)): hosts share a trackable Airbnb link, and bookings that arrive through it pay a **6–10% host fee instead of 15.5%** — but the booking, payment, messaging, reviews and AirCover all stay on Airbnb.
- **Story (1) is losing, not winning.** Among US professionally managed rentals, direct bookings fell from **26% → 23% of reservations** (39% → 35% of revenue) between 2025 and Q2 2026 while Airbnb rose from **46% → 50%** of reservations ([Key Data via The Host Report](https://www.thehostreport.com/news/airbnb-hits-50-of-u-s-reservations-as-direct-bookings-slide)). Roughly two-thirds of operators get <25% of bookings direct and 18% get none, despite 70% having a direct-booking site ([Hostaway 2026 report via PhocusWire](https://www.phocuswire.com/news/short-term-rental-sector-bets-ai-search-drive-direct-bookings)).
- **Story (2) is the real one to model, and it is a take-rate question, not a volume question.** Airbnb is not losing bookings; it is choosing to price host-sourced demand at roughly half the standard fee. Whether that hurts depends on **cannibalization**: at an 8% link fee, the pilot is revenue-neutral if ~52% of link bookings are ones Airbnb would have gotten anyway at 15.5%, accretive below that, dilutive above (see sensitivity below).
- **Sizing:** even a fairly aggressive case — 10% of GBV migrating to links, 70% of it cannibalized — costs ~$220M of revenue, **~1.8% of FY2025 revenue** (~$12.2B) and ~4–5% of adj. EBITDA. A worst case (10% of GBV, 100% cannibalized) is ~$590M / ~4.8% of revenue. Not thesis-breaking on its own; it *is* a headwind to the single-service-fee take-rate uplift the Street has been counting on.
- **Hotel analog says disintermediation fear is overdone.** A decade of "Book Direct" campaigns left OTA share of major-chain hotel bookings at **21% in 2025 vs 20% in 2019**; what hotels actually won was **lower commissions (~13–15% → ~10%)**, not share ([Skift, Jun 12 2026](https://skift.com/2026/06/12/hotels-tried-to-cut-out-expedia-heres-what-happened/)). Expect the same shape for Airbnb: share holds, but effective take rate for professional supply drifts down.
- **Bottom line for the pitch:** direct booking is **not a short thesis** on its own. It is a **take-rate ceiling** argument — worth a line in risks and a sensitivity in the model, not a headline.

## 1. What actually happened (the pilot)

| Item | Detail | Source |
|---|---|---|
| Mechanic | Hosts generate a trackable link in the Listing editor, share on social/email/forums; bookings via the link get a lower host fee. Reservation, payment, guest contact details all stay on Airbnb. | [Skift](https://skift.com/2026/08/29/airbnb-is-testing-lower-fees-for-hosts-who-bring-their-own-guests/), [Houfy](https://www.houfy.com/blog/airbnb-direct-booking-links-what-the-pilot-actually-changes) |
| Fee | 6% or 10% host fee (two tiers, criteria unpublished) vs 15.5% standard | Skift, Houfy |
| Scope | US-only, invitation email to select hosts, week of Aug 29 2026. No help-centre article, no newsroom post; Skift is the only outlet to have reported it. | [Haven Insights](https://www.bookwithhaven.com/blog/airbnbs-direct-booking-test-and-the-future-of-vacation-rental-booking) |
| Airbnb's framing | Email subject: "Share your link, get a lower fee" | Skift |
| Context | Airbnb moved PMS/API hosts to a **15.5% single host-paid fee from Oct 27 2025** (replacing ~3% host + 12–16% guest); all remaining hosts migrate by **Sep 15 2026** (EEA Oct 13). ~50% of active listings were on it as of Q2 2026, 100% by year-end. | [Rental Scale-Up](https://www.rentalscaleup.com/airbnb-host-only-fee/), [Smoobu](https://www.smoobu.com/en/blog/airbnb-host-only-fee-increase/), [Q2-26 call (CFO Ellie Mertz)](https://www.fool.com/earnings/call-transcripts/2026/08/13/airbnb-abnb-q2-2026-earnings-call-transcript/) |

**Read-through:** the pilot is a *response* to the backlash from professional managers over the jump from ~3% to 15.5%. Airbnb is effectively saying: "if you bring the guest, we only charge you for the rails." The 5.5–9.5 pt gap is Airbnb's implied price for its own demand generation ([Houfy](https://www.houfy.com/blog/airbnb-direct-booking-links-what-the-pilot-actually-changes)).

## 2. Is the Book Direct movement a real threat? (Evidence says no)

**Channel mix, US professionally managed STRs (Key Data)** — `data/processed/us_pro_managed_str_channel_mix.csv`

| Channel | 2025 reservations | Q2 2026 reservations | 2025 revenue | Q2 2026 revenue |
|---|---|---|---|---|
| Airbnb | 46% | **50%** | 34% | 37% |
| Direct | 26% | **23%** | 39% | 35% |
| Vrbo | 20% | 20% | 24% | 24% |

Source: [Key Data via The Host Report, Apr 24 2026](https://www.thehostreport.com/news/airbnb-hits-50-of-u-s-reservations-as-direct-bookings-slide). Note this is *professionally managed* supply — the segment most capable of going direct — and direct is still losing share. Key Data's explanation: shorter booking windows push guests to "wherever is fastest and easiest," which is Airbnb.

**Host surveys**
- 70% of operators have a direct-booking website, but **62% get <25% of bookings direct and 18% get zero** ([Hostaway 2026 STR Report via PhocusWire](https://www.phocuswire.com/news/short-term-rental-sector-bets-ai-search-drive-direct-bookings)).
- 38% of hosts reported **no direct bookings in 2025**; 48% got 1–10% ([Hospitable report via PhocusWire](https://www.phocuswire.com/news/short-term-rental-sector-bets-ai-search-drive-direct-bookings)).
- Only 17% of hosts named direct bookings the most impactful trend for 2026, behind AI/automation at 25% (Hospitable via PhocusWire).
- Direct bookings do skew higher-value: **45% longer stays and 51% longer booking windows** than OTA bookings across 1.6M Lodgify bookings ([Lodgify 2026 via Houfy](https://www.houfy.com/blog/direct-booking-statistics-every-str-host-needs-2026)). That is consistent with direct being a *repeat-guest* channel, not an acquisition channel.

**Why direct struggles structurally**
- Airbnb controls the guest relationship: guest email aliases were retired in Aug 2020 and US guest phone numbers are relay numbers that expire 48h after checkout, so hosts cannot build a remarketing list from Airbnb stays ([BetterSTR](https://betterstr.com/blog/2025/12/16/airbnb-blocking-guest-contact-information)).
- Airbnb's supply is mostly individuals: at IPO, 90% of hosts were individual hosts, 79% of them with a single listing, and 72% of nights were with individual hosts ([S-1 via Rental Scale-Up](https://www.rentalscaleup.com/airbnb-host-data-who-are-airbnb-hosts-why-are-individual-hosts-more-important-than-professional-ones/)). A single-listing host has no economic reason to run a website, Stripe account and marketing budget to save 15.5% on a handful of bookings.
- Airbnb's own demand engine is cheap: **~90% of traffic is direct or unpaid** (Airbnb disclosure, discussed critically in [Skift, Aug 17 2026](https://skift.com/2026/08/17/airbnb-has-quietly-rebuilt-the-marketing-engine-it-was-famous-for-cutting/)); FY2025 sales & marketing was $2.588B, ~21% of revenue ([Q4-25 shareholder letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter-Final.pdf)). Caveat from the same Skift piece: S&M is up 32% in 1H26 vs 17% revenue growth, so the "cheap traffic" story is getting more expensive at the margin.

## 3. The hotel analog (why "Book Direct" doesn't kill intermediaries)

- Hotels spent a decade and ~$100M+ on "Book Direct" campaigns (Hilton "Stop Clicking Around" 2016, Marriott "It Pays to Book Direct"). Result: OTA share of major-chain hotel bookings went **20% (2019) → 21% (2025)** — it did not shrink ([Skift Research via Skift, Jun 12 2026](https://skift.com/2026/06/12/hotels-tried-to-cut-out-expedia-heres-what-happened/), survey of ~50k hotels).
- What hotels *did* win: OTA commissions fell from **~13–15% to ~10%**, and loyalty economics improved (Bonvoy members = 75% of Marriott US room nights; Marriott flagship gets only 6–7% of US bookings via OTAs). Same source.
- Mapping to Airbnb: hosts' "direct" push will not take meaningful share (Airbnb's share is *rising*), but the professional cohort — 28% of nights at IPO, likely higher now — has pricing power over the fee. The direct-link pilot is Airbnb conceding that before Vrbo (5% host fee + guest fee, [TabiVista](https://www.tabivista.com/blog/direct-booking-vs-airbnb/)) or Booking.com (15%, same source) can exploit it.
- The difference that matters: hotels had *loyalty programs* to make direct sticky (see `hotel_loyalty_stickiness_vs_abnb.md`). Individual STR hosts don't, which is exactly why direct share is falling in Key Data.

## 4. Sizing the take-rate risk — `analysis/src/direct_link_leakage_sensitivity.py`

**Baseline (FY2025):** GBV $91.3B, revenue $12.2B, implied take rate 13.4%, adj. EBITDA $4.3B ([Q4-25 shareholder letter](https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter-Final.pdf)). Q2 2026 take rate 13.2%, flat YoY; management guides FY26 take rate "relatively flat" ([Q2-26 call](https://www.fool.com/earnings/call-transcripts/2026/08/13/airbnb-abnb-q2-2026-earnings-call-transcript/)).

**Method.** Split link-driven GBV into *cannibalized* (would have booked on Airbnb at 15.5% anyway → revenue on that GBV falls by (1 − fee/15.5%)) and *incremental* (was true off-platform direct → new revenue at fee/15.5% × take rate). EBITDA flow-through assumed 90% (payment processing is the main variable cost on a fee change; assumption, not sourced).

**Break-even cannibalization** (pilot is revenue-neutral): **39% at a 6% fee, 52% at 8%, 65% at 10%.** Below that share of cannibalization the pilot *adds* revenue.

**Net revenue impact, 8% link fee, % of FY2025 revenue** (full grid incl. 6% and 10% fees in `data/processed/direct_link_leakage_sensitivity.csv`; chart in `docs/direct_link_leakage_sensitivity.png`):

| GBV via links → | 2% | 5% | 10% | 15% | 20% |
|---|---|---|---|---|---|
| 25% cannibalized | +0.5% | +1.3% | +2.7% | +4.0% | +5.3% |
| 50% cannibalized | +0.0% | +0.1% | +0.2% | +0.2% | +0.3% |
| 70% cannibalized | −0.4% | −0.9% | −1.8% | −2.8% | −3.7% |
| 100% cannibalized | −1.0% | −2.4% | −4.8% | −7.3% | −9.7% |

**What's a realistic range?** Direct is 23% of reservations / 35% of revenue for US *professionally managed* supply ([Key Data](https://www.thehostreport.com/news/airbnb-hits-50-of-u-s-reservations-as-direct-bookings-slide)), and pro hosts were 28% of Airbnb nights at IPO (S-1 basis; likely higher now). US is a minority of Airbnb GBV and the pilot is US-only for now. A 2–5% GBV migration over 12–24 months looks like the central case; 10% would require global rollout plus heavy uptake by individual hosts, who mostly have no audience to share a link with. At 2–5% of GBV and 70% cannibalization, the hit is **−0.4% to −0.9% of revenue** — inside the noise of FX and RNPL timing that already moves take rate quarter to quarter.

**Why cannibalization is probably high (bear point).** A host who shares an Airbnb link on Instagram is often sharing it with a guest who would have searched Airbnb anyway; Skift's own framing is that "Airbnb's take rate now seems variable." Scott Eddy at [PhocusWire](https://www.phocuswire.com/opinion/opinion-airbnb-making-us-rethink-direct-booking-means) argues these aren't direct bookings at all — Airbnb keeps the guest.

**Why Airbnb still does it (bull point).** Every link booking is a guest account Airbnb acquires at zero CAC, and management has said repeatedly that account growth and cross-sell (hotels, experiences, services) is the priority ([PhocusWire](https://www.phocuswire.com/opinion/opinion-airbnb-making-us-rethink-direct-booking-means), citing Chesky's 2024 comments). If those guests take one extra 15.5% booking a year, the math flips positive quickly. Meanwhile the single-fee migration is finishing (100% of supply by YE26 per CFO), so the *blended* take rate can still tick up even with a link discount on a minority of GBV.

## 5. What would change our mind

| Signal | Bear if… | Bull if… |
|---|---|---|
| Airbnb formalises the pilot (help-centre article / newsroom) | Fee ≤6%, open to all hosts globally, no tier criteria | Stays gated to PMS/pro hosts with volume thresholds |
| Q3/Q4-26 implied take rate | Falls YoY despite single-fee migration completing | Flat/up as guided ("relatively flat", CFO) |
| Key Data channel mix (quarterly) | Direct share stabilises or rebounds | Direct share keeps sliding, Airbnb >50% |
| Vrbo/Booking response | Vrbo cuts host fee below 5% or Booking launches a matching "bring your own guest" rate | No response |
| S&M as % revenue | Keeps rising (28% in 2026 vs 24% in 2024 per Skift) — means Airbnb is *paying* for traffic it used to get free | Reverts toward low-20s |

## 6. Suggested use in the memo

- **Risks section, one bullet:** "Direct-booking-link pilot (6–10% host fee vs 15.5%) caps the take-rate uplift from the single-fee migration; at 5% of GBV migrating and 70% cannibalization the revenue hit is ~1%, EBITDA ~2–3%." Cite Skift + Key Data.
- **Not a thesis driver either way.** If the team lands on a short, the better fee-related angle is *S&M inflation* (Skift: brand + performance marketing +32% in 1H26 vs revenue +17%) eroding the "90% direct traffic" moat — that's a margin story with actual disclosed numbers.
- **Model hook for Krishang/Theo:** add a `link_gbv_share` and `cannibalized_share` input to the revenue build; revenue = GBV × take rate × (1 − link_share × cannib × (1 − link_fee/0.155)) + GBV × take rate × link_share × (1 − cannib) × link_fee/0.155. Script already computes this.

## Caveats
- The pilot is **unconfirmed by Airbnb**; every detail is from Skift's Aug 29 report and host-facing blogs quoting it. Treat fee tiers as reported, not official.
- Key Data covers *professionally managed* US properties only — not representative of Airbnb's global, individual-host-heavy base.
- FY2024 nights split by host type (individual vs professional) is from the 2020 S-1; Airbnb no longer discloses it. If anyone has an AirDNA/Inside Airbnb multi-listing share for 2025–26 it should replace the S-1 figure.
- Stock reaction to the Skift story (Mon Aug 31 2026) not pulled — price APIs are blocked in the cloud session; run locally and add to the ABNB Move Explorer if it cleared the 7% threshold (it almost certainly didn't; ABNB was rallying on the Q2 print through late August per [Yahoo Finance](https://finance.yahoo.com/markets/stocks/articles/airbnb-sales-gains-guidance-boost-123357313.html)).
