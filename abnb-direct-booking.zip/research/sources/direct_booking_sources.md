# Sources — direct booking threat note (append to research/sources/README.md)

| Date accessed | Source | Used for |
|---|---|---|
| 2026-09-06 | Skift, "Airbnb Is Testing Lower Fees for Hosts Who Bring Their Own Guests" (Aug 29 2026) https://skift.com/2026/08/29/airbnb-is-testing-lower-fees-for-hosts-who-bring-their-own-guests/ | Pilot mechanics, 6–10% vs 15.5% fee |
| 2026-09-06 | Houfy, "Airbnb Direct Booking Links: What the Pilot Actually Changes" (Sep 1 2026) https://www.houfy.com/blog/airbnb-direct-booking-links-what-the-pilot-actually-changes | Tiers, US-only, no official terms |
| 2026-09-06 | Haven Insights, "Airbnb's Direct-Booking Test…" https://www.bookwithhaven.com/blog/airbnbs-direct-booking-test-and-the-future-of-vacation-rental-booking | Unconfirmed status, Stripe cost comparison |
| 2026-09-06 | PhocusWire opinion, Scott Eddy https://www.phocuswire.com/opinion/opinion-airbnb-making-us-rethink-direct-booking-means | Bull/bear framing, Chesky account-growth priority |
| 2026-09-06 | The Host Report / Key Data, "Airbnb Hits 50% of U.S. Reservations as Direct Bookings Slide" (Apr 24 2026) https://www.thehostreport.com/news/airbnb-hits-50-of-u-s-reservations-as-direct-bookings-slide | US pro-managed channel mix |
| 2026-09-06 | PhocusWire, "Short-term rental sector bets on AI search to drive direct bookings" https://www.phocuswire.com/news/short-term-rental-sector-bets-ai-search-drive-direct-bookings | Hostaway / Hospitable survey stats |
| 2026-09-06 | Houfy, "Direct Booking Statistics Every STR Host Needs (2026)" https://www.houfy.com/blog/direct-booking-statistics-every-str-host-needs-2026 | Lodgify stay-length / booking-window stats |
| 2026-09-06 | BetterSTR, "Airbnb Is Blocking Guest Contact Information" (Dec 16 2025) https://betterstr.com/blog/2025/12/16/airbnb-blocking-guest-contact-information | Guest contact masking |
| 2026-09-06 | Rental Scale-Up, "New Airbnb Host-only fee Change" https://www.rentalscaleup.com/airbnb-host-only-fee/ | Single-fee migration dates, 3%→15.5% |
| 2026-09-06 | Smoobu, "Airbnb Host Only Fee: July 2026 Update" https://www.smoobu.com/en/blog/airbnb-host-only-fee-increase/ | Sep 15 / Oct 13 2026 deadlines, Brazil/Mexico 16% |
| 2026-09-06 | Rental Scale-Up, "Airbnb host data: Who are Airbnb hosts?" https://www.rentalscaleup.com/airbnb-host-data-who-are-airbnb-hosts-why-are-individual-hosts-more-important-than-professional-ones/ | S-1 individual vs professional host split |
| 2026-09-06 | Skift, "Hotels Spent $100 Million Fighting OTAs. Did It Actually Work?" (Jun 12 2026) https://skift.com/2026/06/12/hotels-tried-to-cut-out-expedia-heres-what-happened/ | Hotel Book Direct analog |
| 2026-09-06 | Skift, "Airbnb Has Quietly Rebuilt the Marketing Engine…" (Aug 17 2026) https://skift.com/2026/08/17/airbnb-has-quietly-rebuilt-the-marketing-engine-it-was-famous-for-cutting/ | 90% direct/unpaid traffic, S&M growth |
| 2026-09-06 | Airbnb Q4-2025 shareholder letter https://s26.q4cdn.com/656283129/files/doc_financials/2025/q4/Airbnb_Q4-2025-Shareholder-Letter-Final.pdf | FY25 GBV, revenue, EBITDA, S&M, take rate |
| 2026-09-06 | Airbnb Q2-2026 results https://news.airbnb.com/airbnb-q2-2026-financial-results/ and call transcript (Motley Fool) https://www.fool.com/earnings/call-transcripts/2026/08/13/airbnb-abnb-q2-2026-earnings-call-transcript/ | Q2 figures, 13.2% take rate, single-fee migration ~50% |
| 2026-09-06 | StockTitan 8-K summary Q1-2026 https://www.stocktitan.net/sec-filings/ABNB/8-k-airbnb-inc-reports-material-event-fa489e87ecd6.html | Q1-26 figures |
| 2026-09-06 | TabiVista, "Direct Booking vs Airbnb (& Vrbo) 2026" https://www.tabivista.com/blog/direct-booking-vs-airbnb/ | Vrbo / Booking.com fee comparison (vendor blog — verify against Vrbo/Booking partner pages before memo) |
