# Drop-in: hotel loyalty stickiness vs ABNB (2026-09-06)

Unzip at repo root; files land in the standard tree.

- research/notes/hotel_loyalty_stickiness_vs_abnb.md — the note (all figures sourced inline)
- research/notes/figures/loyalty_penetration.png — chart used in the note
- data/processed/hotel_loyalty_programs.csv — one row per program: members, penetration, sources
- data/processed/loyalty_stickiness_evidence.csv — every data point in the note, tagged for/against/airbnb, with source URL
- analysis/src/plot_loyalty_penetration.py — regenerates the chart (`python analysis/src/plot_loyalty_penetration.py` from repo root; needs pandas + matplotlib)
- research/sources/loyalty_sources_to_append.md — rows to paste into research/sources/README.md

Suggested branch: jessie/hotel-loyalty
