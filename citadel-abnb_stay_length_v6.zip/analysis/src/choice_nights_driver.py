"""
Choice-probability nights driver for the ABNB revenue model.

Today:  Revenue = Nights x ADR x take rate x FX, with Nights a growth plug.
Here:   Nights_ABNB(t) = SUM_g [ N_g(t) + M_g(t) x P_g(t) ]
        N_g = "own-category" Airbnb nights that would NOT have gone to a hotel anyway
              (62% of Airbnb guests, Farronato & Fradkin survey) - grows with category adoption
        M_g = hotel-contestable lodging demand (party-nights) in segment g = hotel + contestable Airbnb
        P_g = probability a hotel-contestable party in segment g picks Airbnb (share of the pool)
        segments g = party size {solo, pair, 3-4, 5+}; solo carries the business-travel pool.

Base-year (2025, U.S.) calibration:
  Airbnb nights by segment  = U.S. nights x booking share_g x relative stay length_g
  Hotel party-nights by seg = room nights split business/leisure (AHLA), leisure parties by
                              size (Hawaii/Vegas), rooms per party, nights per stay (Kalibri)
  P_g(2025) = contestable Airbnb_g / (contestable Airbnb_g + Hotel_g); own-category = 62% of Airbnb_g

Projection:
  M_g(t)  = M_g(t-1) x (1 + market growth) x (1 + segment mix drift_g)
  logit P_g(t) = logit P_g(t-1) - beta x dln(relative price_g) + product/regulation shift_g
      relative price_g = Airbnb all-in cost / hotel cost for a party of size g
      beta = share sensitivity to relative price (central 2.5, range 1.0-4.3; see note)
  Revenue = Nights x ADR x take rate x FX  (unchanged - plug Nights into the existing model)

Run:  python analysis/src/choice_nights_driver.py
Out:  data/processed/choice_driver_calibration_2025.csv
      data/processed/choice_driver_projection.csv
      data/processed/choice_driver_sensitivity.csv
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "data/processed"
SEG = ["solo", "pair", "3-4", "5+"]

# ---------------- Inputs (every number sourced in research/notes/choice_nights_driver.md) ----------------
NA_NIGHTS_2025 = 158.0            # mm, Airbnb FY2025 10-K regional table
US_SHARE_OF_NA = 0.92             # U.S. = 39% of revenue ($4.76B) / NA revenue $5.196B, FY2025 10-K
NPB_NA = 4.1                      # nights per booking, North America, FY2025 10-K
BOOK_SHARE = {"solo": 0.16, "pair": 0.358, "3-4": 0.323, "5+": 0.159}   # fitted party-size distribution
REL_LEN = {"solo": 1.5, "pair": 0.95, "3-4": 0.9, "5+": 0.8}            # relative stay length (solo 24% nights / 16% bookings; Inside Airbnb by capacity)

US_HOTEL_ROOM_NIGHTS_2025 = 1300 * 1.01   # mm; 1.3B sold in 2024 (STR/CoStar) x ~+1% 2025
BUSINESS_SHARE = 439 / (439 + 605)        # AHLA 2024 SOTI, 2023 room nights
CORP_SOLO = 0.795                         # corporate bookings single-occupancy (Portuguese ledger)
HOTEL_ALOS = 2.1                          # Kalibri Labs
LEIS_PARTY = {"solo": 0.20, "pair": 0.54, "3-4": 0.20, "5+": 0.06}     # leisure hotel parties: mean of Hawaii hotel-only & Las Vegas 2024
LEIS_NIGHTS_REL = {"solo": 0.7, "pair": 1.0, "3-4": 1.0, "5+": 1.0}    # Portuguese ledger: solo 2.5 vs 3.6 nights
ROOMS_PER_PARTY = {"solo": 1.0, "pair": 1.0, "3-4": 1.5, "5+": 2.5}

PRICE_RATIO_2025 = {"solo": 0.69, "pair": 1.22, "3-4": 0.80, "5+": 0.79}  # Airbnb entire home (+14% fee) / hotel rooms x ADR, party_size_cost_crossover.csv
CONTESTABLE = 0.38                # share of Airbnb guests who would have gone to a hotel absent Airbnb (F&F: 62% would not)
BETA = 2.5                        # logit share sensitivity to ln(relative price); range 1.0-4.3 (F&F own-price elasticity -4.27)
CATEGORY_GROWTH = {2026: 0.04, 2027: 0.04, 2028: 0.035, 2029: 0.035, 2030: 0.03}  # own-category nights growth (assumption; NA nights +3% in 2025, total +10% Q2'26)

# Market / price paths (edit these)
YEARS = [2025, 2026, 2027, 2028, 2029, 2030]
MARKET_GROWTH = {2026: 0.017, 2027: 0.011, 2028: 0.015, 2029: 0.015, 2030: 0.015}   # CoStar/TE U.S. demand +1.7% 2026, +1.1% 2027; 1.5% thereafter (assumption)
MIX_DRIFT = {"solo": -0.01, "pair": 0.0, "3-4": 0.02, "5+": 0.04}   # family nights +15% vs Airbnb +8-10%; bedroom nights +12% vs nights +10%
HOTEL_ADR_GROWTH = {2026: 0.031, 2027: 0.016, 2028: 0.025, 2029: 0.025, 2030: 0.025}  # CoStar/TE
ABNB_ADR_GROWTH = {2026: 0.05, 2027: 0.03, 2028: 0.03, 2029: 0.03, 2030: 0.03}         # Q2 2026 ADR +5%; assumption after
PRODUCT_SHIFT = {"solo": 0.0, "pair": 0.0, "3-4": 0.0, "5+": 0.0}   # logit points per year for product / regulation (0 = none)
REST_OF_WORLD_NIGHTS_GROWTH = 0.10   # EMEA/LatAm/APAC nights: apply the team's own assumption; 10% placeholder


def logit(p):
    return np.log(p / (1 - p))


def inv_logit(x):
    return 1 / (1 + np.exp(-x))


def calibrate():
    us_nights = NA_NIGHTS_2025 * US_SHARE_OF_NA
    w = {g: BOOK_SHARE[g] * REL_LEN[g] for g in SEG}
    tot = sum(w.values())
    abnb = {g: us_nights * w[g] / tot for g in SEG}

    biz = US_HOTEL_ROOM_NIGHTS_2025 * BUSINESS_SHARE
    leis = US_HOTEL_ROOM_NIGHTS_2025 - biz
    # leisure: party-nights_g = N x share_g x nights_g ; room-nights = SUM party-nights_g x rooms_g
    unit = sum(LEIS_PARTY[g] * LEIS_NIGHTS_REL[g] * ROOMS_PER_PARTY[g] for g in SEG)
    N = leis / unit
    hotel = {g: N * LEIS_PARTY[g] * LEIS_NIGHTS_REL[g] for g in SEG}
    hotel["solo"] += biz * CORP_SOLO
    hotel["pair"] += biz * (1 - CORP_SOLO)
    rows = []
    for g in SEG:
        c = abnb[g] * CONTESTABLE
        rows.append({"segment": g, "airbnb_nights_mm": abnb[g], "airbnb_own_category_mm": abnb[g] - c,
                     "airbnb_contestable_mm": c, "hotel_party_nights_mm": hotel[g],
                     "contestable_pool_mm": c + hotel[g], "p_airbnb_in_pool": c / (c + hotel[g]),
                     "airbnb_share_all_lodging": abnb[g] / (abnb[g] + hotel[g]),
                     "price_ratio_airbnb_over_hotel": PRICE_RATIO_2025[g]})
    cal = pd.DataFrame(rows)
    t = cal.sum(numeric_only=True)
    cal.loc[len(cal)] = {"segment": "TOTAL", "airbnb_nights_mm": t.airbnb_nights_mm, "airbnb_own_category_mm": t.airbnb_own_category_mm,
                         "airbnb_contestable_mm": t.airbnb_contestable_mm, "hotel_party_nights_mm": t.hotel_party_nights_mm,
                         "contestable_pool_mm": t.contestable_pool_mm, "p_airbnb_in_pool": t.airbnb_contestable_mm / t.contestable_pool_mm,
                         "airbnb_share_all_lodging": t.airbnb_nights_mm / (t.airbnb_nights_mm + t.hotel_party_nights_mm),
                         "price_ratio_airbnb_over_hotel": np.nan}
    return cal


def project(cal, beta=BETA, abnb_adr=ABNB_ADR_GROWTH, hotel_adr=HOTEL_ADR_GROWTH, mix=MIX_DRIFT,
            mkt=MARKET_GROWTH, shift=PRODUCT_SHIFT, cat=CATEGORY_GROWTH):
    base = cal[cal.segment != "TOTAL"].set_index("segment")
    M = base.contestable_pool_mm.to_dict()
    P = base.p_airbnb_in_pool.to_dict()
    N = base.airbnb_own_category_mm.to_dict()
    tot = lambda: sum(N[g] + M[g] * P[g] for g in SEG)
    rows = [{"year": 2025, **{f"M_{g}": M[g] for g in SEG}, **{f"P_{g}": P[g] for g in SEG},
             **{f"N_{g}": N[g] for g in SEG}, "us_nights_mm": tot()}]
    dec = []
    for y in YEARS[1:]:
        prev = tot()
        dln_price = np.log(1 + abnb_adr[y]) - np.log(1 + hotel_adr[y])
        # step 1: market growth on the contestable pool
        M1 = {g: M[g] * (1 + mkt[y]) for g in SEG}
        s_market = sum(N[g] + M1[g] * P[g] for g in SEG)
        # step 2: segment mix drift (both pools)
        M2 = {g: M1[g] * (1 + mix[g]) for g in SEG}
        N2 = {g: N[g] * (1 + mix[g]) for g in SEG}
        s_mix = sum(N2[g] + M2[g] * P[g] for g in SEG)
        # step 3: category adoption on own-category nights
        N3 = {g: N2[g] * (1 + cat[y]) for g in SEG}
        s_cat = sum(N3[g] + M2[g] * P[g] for g in SEG)
        # step 4: share shift from relative price + product
        P4 = {g: inv_logit(logit(P[g]) - beta * dln_price + shift[g]) for g in SEG}
        s_share = sum(N3[g] + M2[g] * P4[g] for g in SEG)
        M, N, P = M2, N3, P4
        rows.append({"year": y, **{f"M_{g}": M[g] for g in SEG}, **{f"P_{g}": P[g] for g in SEG},
                     **{f"N_{g}": N[g] for g in SEG}, "us_nights_mm": s_share})
        dec.append({"year": y, "market_pts": s_market / prev - 1, "mix_pts": (s_mix - s_market) / prev,
                    "category_pts": (s_cat - s_mix) / prev, "share_pts": (s_share - s_cat) / prev,
                    "total": s_share / prev - 1})
    df = pd.DataFrame(rows)
    df["us_nights_growth"] = df.us_nights_mm.pct_change()
    return df, pd.DataFrame(dec)


def main():
    cal = calibrate()
    print(cal.round(3).to_string(index=False))
    df, dec = project(cal)
    print("\n", df[["year", "us_nights_mm", "us_nights_growth"] + [f"P_{g}" for g in SEG]].round(3).to_string(index=False))
    print("\n", dec.round(4).to_string(index=False))
    cal.to_csv(OUT / "choice_driver_calibration_2025.csv", index=False)
    df.merge(dec, on="year", how="left").to_csv(OUT / "choice_driver_projection.csv", index=False)

    # sensitivity: 2030 U.S. nights vs beta and Airbnb ADR premium growth
    sens = []
    for b in [1.0, 2.5, 4.3]:
        for prem in [-0.02, 0.0, 0.02, 0.04]:  # Airbnb ADR growth minus hotel ADR growth, per year
            adr = {y: HOTEL_ADR_GROWTH[y] + prem for y in YEARS[1:]}
            d, _ = project(cal, beta=b, abnb_adr=adr)
            sens.append({"beta": b, "abnb_adr_premium_growth": prem, "us_nights_2030_mm": d.us_nights_mm.iloc[-1],
                         "cagr_2025_30": (d.us_nights_mm.iloc[-1] / d.us_nights_mm.iloc[0]) ** (1 / 5) - 1,
                         "airbnb_share_of_pool_2030": sum(d[f"M_{g}"].iloc[-1] * d[f"P_{g}"].iloc[-1] for g in SEG) / sum(d[f"M_{g}"].iloc[-1] for g in SEG)})
    sens = pd.DataFrame(sens)
    print("\n", sens.round(4).to_string(index=False))
    sens.to_csv(OUT / "choice_driver_sensitivity.csv", index=False)


if __name__ == "__main__":
    main()
