"""Build docs/nights_choice_driver.xlsx - the choice-probability nights driver as live Excel formulas.

Sheets: Inputs (blue = edit), Calibration_2025, Projection, Sensitivity (Python output, pasted).
Mirrors analysis/src/choice_nights_driver.py exactly; recalc with LibreOffice before shipping.
"""
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "docs/nights_choice_driver.xlsx"
SEG = ["solo", "pair", "3-4", "5+"]
YEARS = [2025, 2026, 2027, 2028, 2029, 2030]

BLUE, BLACK, GREEN = Font(name="Arial", size=10, color="0000FF"), Font(name="Arial", size=10), Font(name="Arial", size=10, color="008000")
BOLD = Font(name="Arial", size=10, bold=True)
H1 = Font(name="Arial", size=12, bold=True)
YELLOW = PatternFill("solid", fgColor="FFFF00")
GREY = PatternFill("solid", fgColor="EEEEEE")
PCT, NUM, NUM1 = "0.0%", "#,##0.0", "0.000"

wb = Workbook()

# ------------------------------------------------------------------ Inputs
ws = wb.active
ws.title = "Inputs"
ws.column_dimensions["A"].width = 46
ws.column_dimensions["B"].width = 12
for c in "CDEF":
    ws.column_dimensions[c].width = 12
ws.column_dimensions["G"].width = 90
ws["A1"] = "Choice-probability nights driver — INPUTS"; ws["A1"].font = H1
ws["A2"] = "Blue = hardcoded input you can change. Black = formula. Green = link to another sheet. Yellow = key levers. Every input carries its source in column G."
ws["A2"].font = Font(name="Arial", size=9, italic=True)

rows = [
    ("AIRBNB 2025 (U.S.)", None, None),
    ("Airbnb North America nights 2025 (mm)", 158.0, "Airbnb FY2025 10-K, MD&A regional table — https://www.sec.gov/Archives/edgar/data/1559720/000155972026000004/abnb-20251231.htm"),
    ("U.S. share of North America (revenue proxy)", 0.92, "U.S. = 39% of FY2025 revenue ($4.76B of $12.2B; 61% non-U.S. per 10-K) ÷ NA revenue $5.196B"),
    ("Nights per booking, North America", 4.1, "Airbnb FY2025 10-K"),
    ("Share of Airbnb guests who would have used a hotel absent Airbnb", 0.38, "Farronato & Fradkin (AER 2022): 62% would NOT have switched to a hotel — https://andreyfradkin.com/assets/airbnb_welfare_paper.pdf"),
    ("HOTELS 2025 (U.S.)", None, None),
    ("U.S. hotel room nights sold 2024 (mm)", 1300, "STR/CoStar via HospitalityNet — https://www.hospitalitynet.org/news/4127015.html"),
    ("Room-night growth 2025 (assumed)", 0.01, "Assumption; CoStar/TE 2026 forecast is +1.7%"),
    ("Business share of room nights", 439 / 1044, "AHLA 2024 State of the Industry: 439M business / 605M leisure (2023) — https://www.ahla.com/sites/default/files/SOTI.2024.Final_.Draft_.v4.pdf"),
    ("Corporate bookings single-occupancy share", 0.795, "Hotel Booking Demand dataset (Antonio et al. 2019), corporate segment, n=4,291 — https://www.sciencedirect.com/science/article/pii/S2352340918315191"),
    ("SHARE DYNAMICS", None, None),
    ("Beta: share sensitivity to ln(relative price)", 2.5, "Central 2.5; range 1.0–4.3. F&F average own-price elasticity of accommodation demand −4.27 is the upper bound"),
    ("Rest-of-world nights growth (placeholder, team input)", 0.10, "Not modelled here — plug the team's EMEA/LatAm/APAC assumption"),
]
r = 4
addr = {}
for label, val, src in rows:
    ws.cell(r, 1, label)
    if val is None:
        ws.cell(r, 1).font = BOLD; ws.cell(r, 1).fill = GREY
    else:
        c = ws.cell(r, 2, val); c.font = BLUE
        c.number_format = PCT if (isinstance(val, float) and val < 1 and "Nights per booking" not in label and "Beta" not in label) else "0.00" if "Beta" in label or "Nights per booking" in label else "#,##0.0"
        ws.cell(r, 7, src).font = Font(name="Arial", size=9)
        addr[label] = f"Inputs!$B${r}"
    r += 1
ws.cell(addr["Beta: share sensitivity to ln(relative price)"].split("$")[-1] and int(addr["Beta: share sensitivity to ln(relative price)"].split("$")[-1]), 2).fill = YELLOW
ws.cell(int(addr["Share of Airbnb guests who would have used a hotel absent Airbnb"].split("$")[-1]), 2).fill = YELLOW

# segment table
r += 1
ws.cell(r, 1, "SEGMENT INPUTS (party size)").font = BOLD; ws.cell(r, 1).fill = GREY
r += 1
seg_hdr = ["Segment", "Airbnb booking share", "Airbnb relative stay length", "Hotel leisure party share", "Hotel leisure relative nights", "Hotel rooms per party", "Price ratio 2025 (Airbnb ÷ hotel)", "Mix drift / yr", "Product shift (logit pts/yr)"]
for j, h in enumerate(seg_hdr):
    c = ws.cell(r, 1 + j, h); c.font = BOLD; c.alignment = Alignment(wrap_text=True)
ws.row_dimensions[r].height = 42
seg_vals = {
    "solo": [0.16, 1.5, 0.20, 0.7, 1.0, 0.69, -0.01, 0.0],
    "pair": [0.358, 0.95, 0.54, 1.0, 1.0, 1.22, 0.0, 0.0],
    "3-4": [0.323, 0.9, 0.20, 1.0, 1.5, 0.80, 0.02, 0.0],
    "5+": [0.159, 0.8, 0.06, 1.0, 2.5, 0.79, 0.04, 0.0],
}
seg_row = {}
for g in SEG:
    r += 1
    seg_row[g] = r
    ws.cell(r, 1, g)
    for j, v in enumerate(seg_vals[g]):
        c = ws.cell(r, 2 + j, v); c.font = BLUE
        c.number_format = PCT if j in (0, 2, 6) else "0.00"
    ws.cell(r, 8).fill = YELLOW
r += 1
ws.cell(r, 1, "Sources: booking share = fitted party-size distribution (research/party_size_distribution.md; anchors: guest arrivals ÷ bookings 2.97, Airbnb '>80% of bookings are group trips'). "
        "Relative stay length: solo = 24% of nights ÷ 16% of bookings (Airbnb 2022); others from Inside Airbnb booked-run lengths by capacity. "
        "Hotel leisure party share = mean of Hawaii DBEDT 2024 hotel-only (Table 43) and Las Vegas Visitor Profile 2024. Relative nights: Portuguese ledger (solo 2.5 vs 3.6). "
        "Rooms per party: 2 people/room, families with small kids 1.5. Price ratio: party_size_cost_crossover.csv (Inside Airbnb Jun-2026 medians +14% fee vs rooms × $158.67 ADR). "
        "Mix drift: Airbnb family nights +15% vs total +8–10% (Airbnb Oct 2024); bedroom nights +12% vs nights +10% (Q2 2026).").font = Font(name="Arial", size=9, italic=True)
ws.cell(r, 1).alignment = Alignment(wrap_text=True, vertical="top"); ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=9); ws.row_dimensions[r].height = 70

# year paths
r += 2
ws.cell(r, 1, "YEAR PATHS").font = BOLD; ws.cell(r, 1).fill = GREY
r += 1
ws.cell(r, 1, "Year").font = BOLD
for j, y in enumerate(YEARS):
    ws.cell(r, 2 + j, str(y)).font = BOLD
year_hdr_row = r
paths = [
    ("U.S. lodging demand growth (hotel-contestable pool)", [None, 0.017, 0.011, 0.015, 0.015, 0.015], "CoStar/Tourism Economics Aug-2026: demand +1.7% 2026, +1.1% 2027 — https://www.hospitalitynet.org/news/4133888/us-hotel-forecast-assumptions-august-2026.html; 1.5% after = assumption"),
    ("Hotel ADR growth", [None, 0.031, 0.016, 0.025, 0.025, 0.025], "CoStar/TE: ADR +3.1% 2026, +1.6% 2027 (+2.1% ex World Cup); 2.5% after = assumption"),
    ("Airbnb ADR growth (link to the team's ADR line)", [None, 0.05, 0.03, 0.03, 0.03, 0.03], "Q2 2026 ADR +5% (Airbnb); 3% after = placeholder — REPLACE with the revenue model's ADR growth"),
    ("Own-category nights growth (category adoption)", [None, 0.04, 0.04, 0.035, 0.035, 0.03], "Assumption: Airbnb NA nights +3% 2025, +10% total Q2 2026; own-category = the 62% not contestable by hotels"),
]
path_row = {}
for label, vals, src in paths:
    r += 1
    path_row[label] = r
    ws.cell(r, 1, label)
    for j, v in enumerate(vals):
        if v is not None:
            c = ws.cell(r, 2 + j, v); c.font = BLUE; c.number_format = PCT
    ws.cell(r, 2).value = "—"
    ws.cell(r, 8, src).font = Font(name="Arial", size=9)
ws.cell(path_row["Airbnb ADR growth (link to the team's ADR line)"], 1).fill = YELLOW

# ------------------------------------------------------------------ Calibration_2025
cs = wb.create_sheet("Calibration_2025")
cs.column_dimensions["A"].width = 40
for c in "BCDEFGHIJ":
    cs.column_dimensions[c].width = 15
cs["A1"] = "2025 calibration (U.S.) — party-nights, millions"; cs["A1"].font = H1
hdr = ["Segment", "Airbnb nights", "Own-category Airbnb", "Contestable Airbnb", "Hotel party-nights", "Contestable pool", "P(Airbnb | pool)", "Airbnb share of all lodging"]
for j, h in enumerate(hdr):
    c = cs.cell(3, 1 + j, h); c.font = BOLD; c.alignment = Alignment(wrap_text=True)
cs.row_dimensions[3].height = 32
A = addr
us_nights = f"({A['Airbnb North America nights 2025 (mm)']}*{A['U.S. share of North America (revenue proxy)']})"
wsum = "+".join([f"Inputs!$B${seg_row[g]}*Inputs!$C${seg_row[g]}" for g in SEG])
hotel_rn = f"({A['U.S. hotel room nights sold 2024 (mm)']}*(1+{A['Room-night growth 2025 (assumed)']}))"
biz = f"({hotel_rn}*{A['Business share of room nights']})"
leis = f"({hotel_rn}*(1-{A['Business share of room nights']}))"
unit = "+".join([f"Inputs!$D${seg_row[g]}*Inputs!$E${seg_row[g]}*Inputs!$F${seg_row[g]}" for g in SEG])
cal_row = {}
for i, g in enumerate(SEG):
    rr = 4 + i
    cal_row[g] = rr
    sr = seg_row[g]
    cs.cell(rr, 1, g)
    cs.cell(rr, 2, f"={us_nights}*Inputs!$B${sr}*Inputs!$C${sr}/({wsum})").number_format = NUM
    cs.cell(rr, 3, f"=B{rr}*(1-{A['Share of Airbnb guests who would have used a hotel absent Airbnb']})").number_format = NUM
    cs.cell(rr, 4, f"=B{rr}-C{rr}").number_format = NUM
    extra = f"+{biz}*{A['Corporate bookings single-occupancy share']}" if g == "solo" else f"+{biz}*(1-{A['Corporate bookings single-occupancy share']})" if g == "pair" else ""
    cs.cell(rr, 5, f"={leis}/({unit})*Inputs!$D${sr}*Inputs!$E${sr}{extra}").number_format = NUM
    cs.cell(rr, 6, f"=D{rr}+E{rr}").number_format = NUM
    cs.cell(rr, 7, f"=D{rr}/F{rr}").number_format = PCT
    cs.cell(rr, 8, f"=B{rr}/(B{rr}+E{rr})").number_format = PCT
tr = 8
cs.cell(tr, 1, "TOTAL").font = BOLD
for col in "BCDEF":
    cs[f"{col}{tr}"] = f"=SUM({col}4:{col}7)"; cs[f"{col}{tr}"].number_format = NUM; cs[f"{col}{tr}"].font = BOLD
cs[f"G{tr}"] = f"=D{tr}/F{tr}"; cs[f"G{tr}"].number_format = PCT; cs[f"G{tr}"].font = BOLD
cs[f"H{tr}"] = f"=B{tr}/(B{tr}+E{tr})"; cs[f"H{tr}"].number_format = PCT; cs[f"H{tr}"].font = BOLD
cs["A10"] = "Check: Airbnb U.S. nights = NA nights × U.S. share"; cs["B10"] = f"={us_nights}"; cs["B10"].number_format = NUM
cs["A11"] = "Check: hotel room nights 2025 (mm)"; cs["B11"] = f"={hotel_rn}"; cs["B11"].number_format = NUM
cs["A12"] = "Hotel party-nights < room nights because parties of 3+ take 1.5–2.5 rooms. Business room nights are split solo/pair by the corporate single-occupancy share; leisure room nights are converted to parties with the leisure party mix, relative nights and rooms per party."
cs["A12"].font = Font(name="Arial", size=9, italic=True); cs["A12"].alignment = Alignment(wrap_text=True); cs.merge_cells("A12:H12"); cs.row_dimensions[12].height = 40

# ------------------------------------------------------------------ Projection
ps = wb.create_sheet("Projection")
ps.column_dimensions["A"].width = 46
for j in range(len(YEARS)):
    ps.column_dimensions[get_column_letter(2 + j)].width = 13
ps["A1"] = "Projection — U.S. Airbnb nights from choice probabilities (millions)"; ps["A1"].font = H1
ps["A2"] = "Nights = Σ segments [ own-category nights + contestable pool × P(Airbnb) ].  logit P(t) = logit P(t−1) − β·[ln(1+Airbnb ADR g) − ln(1+hotel ADR g)] + product shift."
ps["A2"].font = Font(name="Arial", size=9, italic=True)
ps["A3"] = "Year".upper(); ps["A3"].font = BOLD
for j, y in enumerate(YEARS):
    ps.cell(3, 2 + j, str(y)).font = BOLD
yc = lambda j: get_column_letter(2 + j)          # projection column for year index j
ic = lambda j: get_column_letter(2 + j)          # Inputs year column (same layout)
beta = A["Beta: share sensitivity to ln(relative price)"]
rp = path_row
ADR_KEY = "Airbnb ADR growth (link to the team's ADR line)"
HOTEL_KEY = 'Hotel ADR growth'
DEM_KEY = 'U.S. lodging demand growth (hotel-contestable pool)'
CAT_KEY = 'Own-category nights growth (category adoption)'
row = 4
ps.cell(row, 1, "Relative price change: ln(1+Airbnb ADR g) − ln(1+hotel ADR g)").font = BOLD
for j in range(1, len(YEARS)):
    ps.cell(row, 2 + j, f"=LN(1+Inputs!{ic(j)}{rp[ADR_KEY]})-LN(1+Inputs!{ic(j)}{rp[HOTEL_KEY]})").number_format = "0.000"
dln_row = row
blocks = {}
for g in SEG:
    row += 2
    ps.cell(row, 1, f"Segment: {g}").font = BOLD; ps.cell(row, 1).fill = GREY
    sr, cr = seg_row[g], cal_row[g]
    # M
    row += 1; mrow = row
    ps.cell(row, 1, "Contestable pool M (hotel + contestable Airbnb)")
    ps.cell(row, 2, f"=Calibration_2025!F{cr}").font = GREEN; ps.cell(row, 2).number_format = NUM
    for j in range(1, len(YEARS)):
        ps.cell(row, 2 + j, f"={yc(j-1)}{row}*(1+Inputs!{ic(j)}{rp[DEM_KEY]})*(1+Inputs!$H${sr})").number_format = NUM
    # N
    row += 1; nrow = row
    ps.cell(row, 1, "Own-category Airbnb nights N")
    ps.cell(row, 2, f"=Calibration_2025!C{cr}").font = GREEN; ps.cell(row, 2).number_format = NUM
    for j in range(1, len(YEARS)):
        ps.cell(row, 2 + j, f"={yc(j-1)}{row}*(1+Inputs!$H${sr})*(1+Inputs!{ic(j)}{rp[CAT_KEY]})").number_format = NUM
    # P
    row += 1; prow = row
    ps.cell(row, 1, "P(Airbnb | contestable pool)")
    ps.cell(row, 2, f"=Calibration_2025!G{cr}").font = GREEN; ps.cell(row, 2).number_format = PCT
    for j in range(1, len(YEARS)):
        prev = f"{yc(j-1)}{row}"
        ps.cell(row, 2 + j, f"=1/(1+EXP(-(LN({prev}/(1-{prev}))-{beta}*{yc(j)}${dln_row}+Inputs!$I${sr})))").number_format = PCT
    # nights
    row += 1; arow = row
    ps.cell(row, 1, f"Airbnb nights — {g}").font = BOLD
    for j in range(len(YEARS)):
        ps.cell(row, 2 + j, f"={yc(j)}{nrow}+{yc(j)}{mrow}*{yc(j)}{prow}").number_format = NUM
        ps.cell(row, 2 + j).font = BOLD
    blocks[g] = dict(M=mrow, N=nrow, P=prow, A=arow)
row += 2
ps.cell(row, 1, "U.S. AIRBNB NIGHTS (mm)").font = H1
tot_row = row
for j in range(len(YEARS)):
    ps.cell(row, 2 + j, "=" + "+".join(f"{yc(j)}{blocks[g]['A']}" for g in SEG)).number_format = NUM
    ps.cell(row, 2 + j).font = BOLD
row += 1
ps.cell(row, 1, "growth")
for j in range(1, len(YEARS)):
    ps.cell(row, 2 + j, f"={yc(j)}{tot_row}/{yc(j-1)}{tot_row}-1").number_format = PCT
growth_row = row
row += 1
ps.cell(row, 1, "Airbnb share of hotel-contestable pool")
for j in range(len(YEARS)):
    num = "+".join(f"{yc(j)}{blocks[g]['M']}*{yc(j)}{blocks[g]['P']}" for g in SEG)
    den = "+".join(f"{yc(j)}{blocks[g]['M']}" for g in SEG)
    ps.cell(row, 2 + j, f"=({num})/({den})").number_format = PCT
row += 1
ps.cell(row, 1, "Airbnb share of all U.S. lodging party-nights")
for j in range(len(YEARS)):
    num = f"{yc(j)}{tot_row}"
    den = "+".join(f"{yc(j)}{blocks[g]['N']}+{yc(j)}{blocks[g]['M']}" for g in SEG)
    ps.cell(row, 2 + j, f"={num}/({den})").number_format = PCT

# revenue plug
row += 2
ps.cell(row, 1, "PLUG INTO THE REVENUE MODEL (U.S. slice)").font = BOLD; ps.cell(row, 1).fill = GREY
row += 1; adr_row = row
ps.cell(row, 1, "Airbnb ADR ($, GBV per night) — team input")
ps.cell(row, 2, 255).font = BLUE; ps.cell(row, 2).number_format = "$#,##0"; ps.cell(row, 2).fill = YELLOW
ps.cell(row, 8, "2025 NA GBV $40.3B ÷ 158M nights = $255 (FY2025 10-K); grows with the Airbnb ADR path on Inputs").font = Font(name="Arial", size=9)
for j in range(1, len(YEARS)):
    ps.cell(row, 2 + j, f"={yc(j-1)}{row}*(1+Inputs!{ic(j)}{rp[ADR_KEY]})").number_format = "$#,##0"
row += 1; take_row = row
ps.cell(row, 1, "Take rate — team input"); ps.cell(row, 8, "FY2025 revenue ÷ GBV = 13.4% (Q4'25 shareholder letter)").font = Font(name="Arial", size=9)
for j in range(len(YEARS)):
    c = ps.cell(row, 2 + j, 0.134); c.font = BLUE; c.number_format = PCT; c.fill = YELLOW
row += 1; fx_row = row
ps.cell(row, 1, "FX factor (1.00 for USD) — team input")
for j in range(len(YEARS)):
    c = ps.cell(row, 2 + j, 1.0); c.font = BLUE; c.number_format = "0.00"
row += 1
ps.cell(row, 1, "U.S. GBV ($mm) = nights × ADR × FX").font = BOLD
for j in range(len(YEARS)):
    ps.cell(row, 2 + j, f"={yc(j)}{tot_row}*{yc(j)}{adr_row}*{yc(j)}{fx_row}").number_format = "$#,##0"
gbv_row = row
row += 1
ps.cell(row, 1, "U.S. revenue ($mm) = GBV × take rate").font = BOLD
for j in range(len(YEARS)):
    c = ps.cell(row, 2 + j, f"={yc(j)}{gbv_row}*{yc(j)}{take_row}"); c.number_format = "$#,##0"; c.font = BOLD
row += 2
ps.cell(row, 1, "How to wire it: replace the U.S./North-America nights growth plug in the team model with row " + str(tot_row) +
        " (or its growth in row " + str(growth_row) + "). Keep ADR, take rate and FX where they are — this sheet only explains NIGHTS. "
        "For other regions, either repeat the calibration with that region's hotel data or apply the rest-of-world growth input.").font = Font(name="Arial", size=9, italic=True)
ps.cell(row, 1).alignment = Alignment(wrap_text=True); ps.merge_cells(start_row=row, start_column=1, end_row=row, end_column=7); ps.row_dimensions[row].height = 48

# ------------------------------------------------------------------ Sensitivity (python output)
ss = wb.create_sheet("Sensitivity")
ss.column_dimensions["A"].width = 12
for c in "BCDE":
    ss.column_dimensions[c].width = 22
ss["A1"] = "Sensitivity — 2030 U.S. Airbnb nights (mm) and 2025–30 CAGR"; ss["A1"].font = H1
ss["A2"] = "Values computed by analysis/src/choice_nights_driver.py (same model); rows = beta, columns = Airbnb ADR growth minus hotel ADR growth per year. Static output, not formulas."
ss["A2"].font = Font(name="Arial", size=9, italic=True)
sens = pd.read_csv(ROOT / "data/processed/choice_driver_sensitivity.csv")
piv = sens.pivot(index="beta", columns="abnb_adr_premium_growth", values="us_nights_2030_mm")
cag = sens.pivot(index="beta", columns="abnb_adr_premium_growth", values="cagr_2025_30")
ss["A4"] = "beta \\ ADR premium"; ss["A4"].font = BOLD
for j, col in enumerate(piv.columns):
    c = ss.cell(4, 2 + j, f"{col:+.0%}/yr"); c.font = BOLD
for i, b in enumerate(piv.index):
    ss.cell(5 + i, 1, b).font = BLUE
    for j, col in enumerate(piv.columns):
        ss.cell(5 + i, 2 + j, round(float(piv.loc[b, col]), 1)).number_format = NUM
r0 = 5 + len(piv.index) + 1
ss.cell(r0, 1, "CAGR 2025–30").font = BOLD
for i, b in enumerate(cag.index):
    ss.cell(r0 + 1 + i, 1, b).font = BLUE
    for j, col in enumerate(cag.columns):
        ss.cell(r0 + 1 + i, 2 + j, float(cag.loc[b, col])).number_format = PCT

for sh in wb.worksheets:
    for rowc in sh.iter_rows():
        for c in rowc:
            if c.font is None or c.font.name != "Arial":
                c.font = Font(name="Arial", size=c.font.size or 10, bold=c.font.bold, italic=c.font.italic, color=c.font.color)
OUT.parent.mkdir(parents=True, exist_ok=True)
wb.save(OUT)
print("wrote", OUT)
