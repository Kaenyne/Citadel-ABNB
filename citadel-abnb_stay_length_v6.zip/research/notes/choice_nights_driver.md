# Choice-probability nights driver for the revenue model

Readable version: artifact "Nights Choice Driver" (claude.ai/code/artifact/5e19c458-b7ee-4dba-a6f4-0cc16b308b49). Excel: `docs/nights_choice_driver.xlsx` (Inputs / Calibration_2025 / Projection / Sensitivity, 178 live formulas). Python: `analysis/src/choice_nights_driver.py`.

## The idea

Team model: Revenue = Nights × ADR × take rate × FX, Nights is a plug. Replace the plug:

    Nights_ABNB(t) = Σ_g [ N_g(t) + M_g(t) × P_g(t) ]        g = party size {solo, pair, 3–4, 5+}
    N_g  own-category Airbnb nights (62% of guests would NOT have used a hotel — Farronato & Fradkin) → grows with category adoption
    M_g  hotel-contestable party-nights = hotel party-nights + 38% of Airbnb nights → grows with U.S. lodging demand + mix drift
    P_g  P(Airbnb | contestable party):  logit P_g(t) = logit P_g(t−1) − β·[ln(1+ADR_abnb) − ln(1+ADR_hotel)] + product shift
    Revenue = Nights × ADR × take rate × FX  (unchanged)

## 2025 U.S. calibration

| Party | Airbnb nights | own-cat. | contestable | Hotel party-nights | P(Airbnb \| pool) | Airbnb share of all lodging | Airbnb ÷ hotel price |
|---|---|---|---|---|---|---|---|
| Solo (incl. business) | 35.0 | 21.7 | 13.3 | 533.2 | 2.4% | 6.2% | 0.69x |
| Pair | 49.5 | 30.7 | 18.8 | 476.8 | 3.8% | 9.4% | 1.22x |
| 3–4 | 42.3 | 26.3 | 16.1 | 134.7 | 10.7% | 23.9% | 0.80x |
| 5+ | 18.5 | 11.5 | 7.0 | 40.4 | 14.8% | 31.4% | 0.79x |
| Total | 145.4 | 90.1 | 55.2 | 1,185.1 | 4.5% | 10.9% | — |

- Airbnb U.S. nights = NA 158M × 92% (U.S. = 39% of revenue vs NA 43%, FY2025 10-K) split by fitted party distribution (16/36/32/16%) × relative stay length (1.5/0.95/0.9/0.8).
- Hotel party-nights = 1.3B room nights (STR 2024, +1%) → 42% business (AHLA 439M/605M), 80% single-occupancy (Portuguese ledger) → leisure parties 20/54/20/6% (Hawaii + Vegas) with rooms per party 1/1/1.5/2.5.
- Airbnb = 10.9% of U.S. lodging party-nights; share rises 6% → 31% from solo to 5+.

## Base-case projection (U.S.)

| | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 |
|---|---|---|---|---|---|---|
| U.S. Airbnb nights (mm) | 145.4 | 148.8 | 152.8 | 157.9 | 163.2 | 168.3 |
| growth | | 2.4% | 2.7% | 3.3% | 3.4% | 3.1% |
| of which market / mix / category / share (pts) | | 0.7 / 0.9 / 2.5 / −1.6 | 0.4 / 0.9 / 2.6 / −1.2 | 0.5 / 0.9 / 2.3 / −0.4 | 0.5 / 0.9 / 2.3 / −0.4 | 0.5 / 1.0 / 2.0 / −0.4 |

Inputs: CoStar/TE demand +1.7%/+1.1% then 1.5%; hotel ADR +3.1%/+1.6% then 2.5%; Airbnb ADR +5% then 3% (placeholder — link to team ADR); own-category growth 4% → 3%; mix drift solo −1%, 3–4 +2%, 5+ +4%; β = 2.5.

## Sensitivity — 2025–30 U.S. nights CAGR (rows β, cols Airbnb ADR growth − hotel ADR growth per year)

| β | −2 pts | 0 | +2 pts | +4 pts |
|---|---|---|---|---|
| 1.0 | 4.4% | 3.7% | 3.1% | 2.5% |
| 2.5 | 5.5% | 3.7% | 2.2% | 0.9% |
| 4.3 | 7.0% | 3.7% | 1.2% | −0.6% |

Every point of ADR premium growth costs ~0.7 pts of nights growth at β = 2.5 (1.3 at 4.3).

## New data pulled for this

- Farronato & Fradkin (AER 2022): 62% of Airbnb guests would not have switched to a hotel (87% at peak); accommodation own-price elasticity −4.27 (−2.9 economy Airbnb to −8.6 luxury hotel, SF); hotels in top-10 cities lost 1.3% of nights / 1.5% of revenue in 2014. https://andreyfradkin.com/assets/airbnb_welfare_paper.pdf ; https://www.library.hbs.edu/working-knowledge/the-airbnb-effect-cheaper-rooms-for-travelers-less-revenue-for-hotels
- CoStar / Tourism Economics Aug-2026 U.S. forecast: 2026 demand +1.7%, ADR +3.1%, RevPAR +4.4%, supply +0.4%; 2027 demand +1.1%, ADR +1.6% (+2.1% ex World Cup). https://www.hospitalitynet.org/news/4133888/us-hotel-forecast-assumptions-august-2026.html
- AirDNA 2026 outlook: STR supply +4.6%, ADR +1.5%, occupancy −1%. https://www.prnewswire.com/news-releases/2026-will-be-the-best-year-to-invest-in-short-term-rentals-since-2021-new-airdna-report-finds-302643393.html
- Airbnb Q2 2026: nights +10%, ADR $183.73 (+5%), bedroom nights +12%. https://howtheymake.money/en/blog/abnb-q2-2026-hotels-accelerate
- Everything else: party-size, stay-length, cross-over and hotel notes already in the repo (AHLA, STR 1.3B, Hawaii DBEDT, Las Vegas, Portuguese ledger, Inside Airbnb, Kalibri).

## Wiring

1. Link Inputs!"Airbnb ADR growth" to the model's ADR line (same ADR drives price and share).
2. Replace the NA/U.S. nights growth plug with Projection!"U.S. AIRBNB NIGHTS" (or its growth row). ADR, take rate, FX untouched. Check: 2025 U.S. revenue reproduces at $5.0B vs ~$4.8B reported (U.S.-share proxy).
3. Other regions: keep the team's growth for now, or recalibrate with regional hotel nights (Eurostat for EU — Krishang's file).
4. Scenarios: bear = ADR +2–4 pts above hotels, β 2.5–4.3 → nights CAGR 1–2%; bull = ADR parity, mix drift +2, positive product shift → 4–5%.

## Caveats

- U.S. nights proxied by revenue share; 38% substitution is 2014 big-city survey data (13% at peak) and is the biggest lever; β is a share response, −4.27 is an upper bound; hotel party-nights are derived, not observed; no explicit supply/regulation channel beyond the product-shift lever.

## Files

- `analysis/src/choice_nights_driver.py`, `analysis/src/build_nights_driver_xlsx.py`
- `docs/nights_choice_driver.xlsx`, `docs/nights_choice_driver.html`
- `data/processed/choice_driver_calibration_2025.csv`, `choice_driver_projection.csv`, `choice_driver_sensitivity.csv`
