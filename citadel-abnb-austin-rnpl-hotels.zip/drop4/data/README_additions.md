# Rows to append to data/README.md (drop 4, 2026-09-05, Jessie)

| File | Source | Pulled by | Date | Notes |
|---|---|---|---|---|
| processed/austin_active_str_daily.csv | City of Austin Development Services, Socrata `mydx-h5dy` (Active Short Term Rental Counts) | Jessie (Claude) | 2026-09-05 | Daily total active STR licences, 2025-02-28 + 2025-03-13..2026-09-05 (527 dates). SoQL in `analysis/src/austin_str_daily.py`. Licences, not listings. Open government data. |
| processed/austin_str_by_type_monthly_raw.csv | same | Jessie (Claude) | 2026-09-05 | Sum of daily counts per month x licence type; divide by dates-in-month (script does it) for a monthly average. |
| processed/austin_str_by_type_monthly_avg.csv | derived | Jessie (Claude) | 2026-09-05 | Monthly average active licences by type. Rebuild: `python analysis/src/austin_str_daily.py`. |
| processed/austin_str_by_district_type_snapshots.csv | same Socrata dataset | Jessie (Claude) | 2026-09-05 | 2025-03-13 vs 2026-09-05, council district x licence type. |
| processed/inside_airbnb_reviews_by_market_quarter.csv (to be produced) | Inside Airbnb `reviews.csv.gz`, Theo's volume | Theo | pending | Output of `analysis/src/count_reviews_duckdb.py`; quarterly review counts per market + YoY, partial last quarter dropped. |
| processed/inside_airbnb_reviews_us_total_quarter.csv (to be produced) | same | Theo | pending | US sum + YoY; join to NA revenue YoY. |

# Rows to append to research/sources/README.md

| Source | URL | Used for | Licence |
|---|---|---|---|
| City of Austin, Active Short Term Rental Counts | https://data.austintexas.gov/resource/mydx-h5dy.json | Austin licence supply by type/district | Open data |
| City of Austin, Short-Term Rentals (ordinance timeline) | https://www.austintexas.gov/department/short-term-rentals | Feb-2025 zoning, Oct-2025 rules, Jul-2026 platform rule | Public |
| Farronato & Fradkin (AER 2022); Zervas, Proserpio & Byers (JMR 2017); Guttentag et al. (JTR 2018) | journal pages | Airbnb-vs-hotel substitution evidence | Academic, cite only |
| Upgraded Points, NerdWallet/Harris, CoStar/STR, Skift Research, Phocuswright | press pages | Survey layer on hotel-vs-STR choice | Cite only; re-verify figures |
