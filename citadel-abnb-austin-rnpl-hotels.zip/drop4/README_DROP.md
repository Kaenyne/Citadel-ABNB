# Drop 4 (2026-09-05, Jessie): Austin daily STR counts, RNPL read, hotel-vs-Airbnb factors, review counter for Theo

Unzip at the repo root on a branch (e.g. `jessie/austin-rnpl-hotels`) and open a PR. Nothing here overwrites a teammate's file.

```
analysis/src/austin_str_daily.py                 builds figures 05-07 and the monthly-avg CSV from the Austin CSVs
analysis/src/count_reviews_duckdb.py             FOR THEO: counts reviews per market per quarter over the files on the SSD
analysis/figures/05_austin_daily_active_str.png
analysis/figures/06_austin_str_by_type.png
analysis/figures/07_austin_str_by_district.png
data/processed/austin_active_str_daily.csv
data/processed/austin_str_by_type_monthly_raw.csv
data/processed/austin_str_by_type_monthly_avg.csv
data/processed/austin_str_by_district_type_snapshots.csv
data/README_additions.md                         rows to paste into data/README.md and research/sources/README.md, then delete this file
research/notes/2026-09-05_austin-str-rnpl-hotel-factors.md
research/notes/2026-09-05_macro-topdown-framework.md   REPLACES the earlier version: oil row now marked spurious
```

Reproduce: `pip install pandas matplotlib` then `python analysis/src/austin_str_daily.py` from the repo root.
